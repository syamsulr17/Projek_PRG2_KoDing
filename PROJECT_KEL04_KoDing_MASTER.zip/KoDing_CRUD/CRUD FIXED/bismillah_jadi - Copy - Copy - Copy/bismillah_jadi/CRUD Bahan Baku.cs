﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace bismillah_jadi
{
    public partial class CRUDBahan : UserControl
    {
        
        public CRUDBahan()
        {
            InitializeComponent();
            
           
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            
            
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
          
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
          
        }

        private void hapus_Paint(object sender, PaintEventArgs e)
        {

        }
        public delegate void InvalidUserEntryEvent(object sender, KeyPressEventArgs e);
        //public event InvalidUserEntryEvent InvalidUserEntry;
        private void txttmbhbahan_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txttmbhbahan_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txttbhhargabahan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsLetter(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }



        private void btntambah_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();


            try
            {
                if (txttbhid.Text == "" || txttbhnama.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {


                    DataTable dtData = new DataTable();
                    SqlCommand insert = new SqlCommand("sp_InsertBahanBaku", connection);
                    insert.CommandType = CommandType.StoredProcedure;
                    insert.Parameters.AddWithValue("@id_bahan", txttbhid.Text);
                    insert.Parameters.AddWithValue("@nama_bahan", txttbhnama.Text);
                    int numRes = insert.ExecuteNonQuery();
                    if (numRes > 0)
                    {
                        MessageBox.Show("Data Bahan Baku Berhasil Disimpan!");
                        clear();
                        Refreshdata();

                        string query = "select id_bahan from [dbo].[Bahan Baku] order by id_bahan desc";
                        txttbhid.Text = autoNumber("BHN-", query);
                    }
                    else
                        MessageBox.Show("Gagal Menyimpan! Coba Lagi!");
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

private void Refreshdata()
        {
            this.bahan_BakuTableAdapter.Fill(this.koDingDataSet13.Bahan_Baku);
        }
        private void clear()
        {
            
            txttbhnama.Text = "";
        }

        private void btnbatal_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void Kelola_Data_Load(object sender, EventArgs e)
        {

            string query = "select id_bahan from [dbo].[Bahan Baku] order by id_bahan desc";
            txttbhid.Text= autoNumber("BHN-", query);
            
            this.bahan_BakuTableAdapter.Fill(this.koDingDataSet13.Bahan_Baku);
            bunifuCustomDataGrid3.AutoGenerateColumns = false;
            

        }

        private void tambahbahan_Paint(object sender, PaintEventArgs e)
        {

        }
        private string autoNumber(string firstText, string query)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            string result = "";
            int num = 0;
            try
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;

        }

        private void txtupdatenama_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsLetter(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }



        private void btnupdate_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();



            try
            {
                if (txtupdateid.Text == "" || txtupdatenama.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    
                    SqlCommand update = new SqlCommand("sp_UpdateBahanBaku", connection);
                    update.CommandType = CommandType.StoredProcedure;

                    update.Parameters.AddWithValue("@id_bahan", txtupdateid.Text);
                    update.Parameters.AddWithValue("@nama_bahan", txtupdatenama.Text);
                    update.ExecuteNonQuery();
                    MessageBox.Show("Berhasil Memperbaharui Data!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);  
                    Refreshdata();
                    txtupdateid.Text = "---Pilih ID Bahan---";
                    txtupdatenama.Clear();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Pembaruan Gagal!" + ex.Message.ToString());
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            try
                {
                if (txtupdateid.Text == "" || txtupdatenama.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string message = "Hapus Data??";
                    string title = "Confirmation";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result = MessageBox.Show(message, title, buttons);
                    if (result == DialogResult.Yes)
                    {

                        SqlCommand delete = new SqlCommand("sp_DeleteBahanBaku", connection);
                        delete.CommandType = CommandType.StoredProcedure;

                        delete.Parameters.AddWithValue("@id_bahan", txtupdateid.Text);
                        int numRes = delete.ExecuteNonQuery();
                        if (numRes >= 0)
                        {
                            MessageBox.Show("Bahan Baku Berhasil Dihapus!", "Infomation!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            Refreshdata();
                            txtupdateid.Text = "---Pilih ID Bahan---";
                            txtupdatenama.Clear();
                        }
                        else
                            MessageBox.Show("Gagal Menghapus! Coba Lagi!");
                    }
                    else
                    {
                        txtupdateid.Text = "---Pilih ID Bahan---";
                        txtupdatenama.Clear();
                    }
                }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        

        private void btntambahbahan_Click(object sender, EventArgs e)
        {
            string query = "select id_bahan from [dbo].[Bahan Baku] order by id_bahan desc";
            txttbhid.Text = autoNumber("BHN-", query);

            perbaruibahan.Visible = false;
            tambahbahan.Visible = true;
        }

        private void btnperbaruibahan_Click(object sender, EventArgs e)
        {
           
            perbaruibahan.Visible = true;
            tambahbahan.Visible = false;
        }

        private void txtupdateid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            SqlCommand dbcmd = connection.CreateCommand();
            string sql = "select * from [dbo].[Bahan Baku] where id_bahan='" + txtupdateid.Text + "'";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();
            reader.Read();
            txtupdatenama.Text = reader.GetValue(1).ToString();
        }

        private void perbaruibahan_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
