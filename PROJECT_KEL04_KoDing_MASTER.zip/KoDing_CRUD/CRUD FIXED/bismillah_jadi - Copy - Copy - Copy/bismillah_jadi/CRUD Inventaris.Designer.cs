﻿namespace bismillah_jadi
{
    partial class CRUD_Inventaris
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CRUD_Inventaris));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnperbaruibahan = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btntambahbahan = new Bunifu.Framework.UI.BunifuFlatButton();
            this.tambahbahan = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomTextbox1 = new Bunifu.Framework.BunifuCustomTextbox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txttbhid = new Bunifu.Framework.BunifuCustomTextbox();
            this.bunifuCustomDataGrid3 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.idinventarisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.namabarangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jumlahbarangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inventarisBarangBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.koDingDataSet24 = new bismillah_jadi.KoDingDataSet24();
            this.btnbatal = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btntambah = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.txttbhnama = new Bunifu.Framework.BunifuCustomTextbox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.perbaruibahan = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomTextbox2 = new Bunifu.Framework.BunifuCustomTextbox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtupdateid = new System.Windows.Forms.ComboBox();
            this.update = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.idinventarisDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.namabarangDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jumlahbarangDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btndelete = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnupdate = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtupdatenama = new Bunifu.Framework.BunifuCustomTextbox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.inventaris_BarangTableAdapter = new bismillah_jadi.KoDingDataSet24TableAdapters.Inventaris_BarangTableAdapter();
            this.panel1.SuspendLayout();
            this.tambahbahan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventarisBarangBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.koDingDataSet24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.perbaruibahan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.update)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkCyan;
            this.panel1.Controls.Add(this.btnperbaruibahan);
            this.panel1.Controls.Add(this.btntambahbahan);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(586, 47);
            this.panel1.TabIndex = 16;
            // 
            // btnperbaruibahan
            // 
            this.btnperbaruibahan.Active = false;
            this.btnperbaruibahan.Activecolor = System.Drawing.Color.DarkCyan;
            this.btnperbaruibahan.BackColor = System.Drawing.Color.DarkCyan;
            this.btnperbaruibahan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnperbaruibahan.BorderRadius = 0;
            this.btnperbaruibahan.ButtonText = "Perbarui";
            this.btnperbaruibahan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnperbaruibahan.DisabledColor = System.Drawing.Color.Gray;
            this.btnperbaruibahan.Iconcolor = System.Drawing.Color.Transparent;
            this.btnperbaruibahan.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnperbaruibahan.Iconimage")));
            this.btnperbaruibahan.Iconimage_right = null;
            this.btnperbaruibahan.Iconimage_right_Selected = null;
            this.btnperbaruibahan.Iconimage_Selected = null;
            this.btnperbaruibahan.IconMarginLeft = 0;
            this.btnperbaruibahan.IconMarginRight = 0;
            this.btnperbaruibahan.IconRightVisible = true;
            this.btnperbaruibahan.IconRightZoom = 0D;
            this.btnperbaruibahan.IconVisible = true;
            this.btnperbaruibahan.IconZoom = 90D;
            this.btnperbaruibahan.IsTab = false;
            this.btnperbaruibahan.Location = new System.Drawing.Point(145, 0);
            this.btnperbaruibahan.Name = "btnperbaruibahan";
            this.btnperbaruibahan.Normalcolor = System.Drawing.Color.DarkCyan;
            this.btnperbaruibahan.OnHovercolor = System.Drawing.Color.Cyan;
            this.btnperbaruibahan.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnperbaruibahan.selected = false;
            this.btnperbaruibahan.Size = new System.Drawing.Size(148, 44);
            this.btnperbaruibahan.TabIndex = 13;
            this.btnperbaruibahan.Text = "Perbarui";
            this.btnperbaruibahan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnperbaruibahan.Textcolor = System.Drawing.Color.Black;
            this.btnperbaruibahan.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnperbaruibahan.Click += new System.EventHandler(this.btnperbaruibahan_Click);
            // 
            // btntambahbahan
            // 
            this.btntambahbahan.Active = false;
            this.btntambahbahan.Activecolor = System.Drawing.Color.DarkCyan;
            this.btntambahbahan.BackColor = System.Drawing.Color.DarkCyan;
            this.btntambahbahan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btntambahbahan.BorderRadius = 0;
            this.btntambahbahan.ButtonText = "Tambah";
            this.btntambahbahan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btntambahbahan.DisabledColor = System.Drawing.Color.Gray;
            this.btntambahbahan.Iconcolor = System.Drawing.Color.Transparent;
            this.btntambahbahan.Iconimage = ((System.Drawing.Image)(resources.GetObject("btntambahbahan.Iconimage")));
            this.btntambahbahan.Iconimage_right = null;
            this.btntambahbahan.Iconimage_right_Selected = null;
            this.btntambahbahan.Iconimage_Selected = null;
            this.btntambahbahan.IconMarginLeft = 0;
            this.btntambahbahan.IconMarginRight = 0;
            this.btntambahbahan.IconRightVisible = true;
            this.btntambahbahan.IconRightZoom = 0D;
            this.btntambahbahan.IconVisible = true;
            this.btntambahbahan.IconZoom = 90D;
            this.btntambahbahan.IsTab = false;
            this.btntambahbahan.Location = new System.Drawing.Point(0, 0);
            this.btntambahbahan.Name = "btntambahbahan";
            this.btntambahbahan.Normalcolor = System.Drawing.Color.DarkCyan;
            this.btntambahbahan.OnHovercolor = System.Drawing.Color.Cyan;
            this.btntambahbahan.OnHoverTextColor = System.Drawing.Color.Black;
            this.btntambahbahan.selected = false;
            this.btntambahbahan.Size = new System.Drawing.Size(148, 44);
            this.btntambahbahan.TabIndex = 11;
            this.btntambahbahan.Text = "Tambah";
            this.btntambahbahan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btntambahbahan.Textcolor = System.Drawing.Color.Black;
            this.btntambahbahan.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntambahbahan.Click += new System.EventHandler(this.btntambahbahan_Click);
            // 
            // tambahbahan
            // 
            this.tambahbahan.BackColor = System.Drawing.Color.Cyan;
            this.tambahbahan.Controls.Add(this.pictureBox3);
            this.tambahbahan.Controls.Add(this.bunifuCustomTextbox1);
            this.tambahbahan.Controls.Add(this.label5);
            this.tambahbahan.Controls.Add(this.label6);
            this.tambahbahan.Controls.Add(this.txttbhid);
            this.tambahbahan.Controls.Add(this.bunifuCustomDataGrid3);
            this.tambahbahan.Controls.Add(this.btnbatal);
            this.tambahbahan.Controls.Add(this.btntambah);
            this.tambahbahan.Controls.Add(this.pictureBox5);
            this.tambahbahan.Controls.Add(this.pictureBox6);
            this.tambahbahan.Controls.Add(this.txttbhnama);
            this.tambahbahan.Controls.Add(this.label9);
            this.tambahbahan.Controls.Add(this.label10);
            this.tambahbahan.Controls.Add(this.label11);
            this.tambahbahan.Controls.Add(this.label12);
            this.tambahbahan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tambahbahan.Location = new System.Drawing.Point(0, 47);
            this.tambahbahan.Name = "tambahbahan";
            this.tambahbahan.Size = new System.Drawing.Size(586, 374);
            this.tambahbahan.TabIndex = 68;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::bismillah_jadi.Properties.Resources.icons8_fridge_96;
            this.pictureBox3.Location = new System.Drawing.Point(32, 157);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(18, 18);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 38;
            this.pictureBox3.TabStop = false;
            // 
            // bunifuCustomTextbox1
            // 
            this.bunifuCustomTextbox1.BackColor = System.Drawing.Color.Cyan;
            this.bunifuCustomTextbox1.BorderColor = System.Drawing.Color.SeaGreen;
            this.bunifuCustomTextbox1.Location = new System.Drawing.Point(190, 157);
            this.bunifuCustomTextbox1.MaxLength = 50;
            this.bunifuCustomTextbox1.Name = "bunifuCustomTextbox1";
            this.bunifuCustomTextbox1.Size = new System.Drawing.Size(155, 20);
            this.bunifuCustomTextbox1.TabIndex = 37;
            this.bunifuCustomTextbox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.bunifuCustomTextbox1_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(172, 157);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(12, 18);
            this.label5.TabIndex = 36;
            this.label5.Text = ":";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(56, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 18);
            this.label6.TabIndex = 35;
            this.label6.Text = "Jumlah Barang";
            // 
            // txttbhid
            // 
            this.txttbhid.BackColor = System.Drawing.Color.Cyan;
            this.txttbhid.BorderColor = System.Drawing.Color.SeaGreen;
            this.txttbhid.Location = new System.Drawing.Point(190, 85);
            this.txttbhid.MaxLength = 10;
            this.txttbhid.Name = "txttbhid";
            this.txttbhid.ReadOnly = true;
            this.txttbhid.Size = new System.Drawing.Size(155, 20);
            this.txttbhid.TabIndex = 34;
            // 
            // bunifuCustomDataGrid3
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuCustomDataGrid3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.bunifuCustomDataGrid3.AutoGenerateColumns = false;
            this.bunifuCustomDataGrid3.BackgroundColor = System.Drawing.Color.LightCyan;
            this.bunifuCustomDataGrid3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuCustomDataGrid3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuCustomDataGrid3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.bunifuCustomDataGrid3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bunifuCustomDataGrid3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idinventarisDataGridViewTextBoxColumn,
            this.namabarangDataGridViewTextBoxColumn,
            this.jumlahbarangDataGridViewTextBoxColumn});
            this.bunifuCustomDataGrid3.DataSource = this.inventarisBarangBindingSource;
            this.bunifuCustomDataGrid3.DoubleBuffered = true;
            this.bunifuCustomDataGrid3.EnableHeadersVisualStyles = false;
            this.bunifuCustomDataGrid3.GridColor = System.Drawing.Color.DarkSlateGray;
            this.bunifuCustomDataGrid3.HeaderBgColor = System.Drawing.Color.LightSeaGreen;
            this.bunifuCustomDataGrid3.HeaderForeColor = System.Drawing.Color.Black;
            this.bunifuCustomDataGrid3.Location = new System.Drawing.Point(361, 85);
            this.bunifuCustomDataGrid3.Name = "bunifuCustomDataGrid3";
            this.bunifuCustomDataGrid3.ReadOnly = true;
            this.bunifuCustomDataGrid3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.bunifuCustomDataGrid3.Size = new System.Drawing.Size(213, 148);
            this.bunifuCustomDataGrid3.TabIndex = 33;
            // 
            // idinventarisDataGridViewTextBoxColumn
            // 
            this.idinventarisDataGridViewTextBoxColumn.DataPropertyName = "id_inventaris";
            this.idinventarisDataGridViewTextBoxColumn.HeaderText = "ID Inventaris";
            this.idinventarisDataGridViewTextBoxColumn.Name = "idinventarisDataGridViewTextBoxColumn";
            this.idinventarisDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // namabarangDataGridViewTextBoxColumn
            // 
            this.namabarangDataGridViewTextBoxColumn.DataPropertyName = "nama_barang";
            this.namabarangDataGridViewTextBoxColumn.HeaderText = "Nama Barang";
            this.namabarangDataGridViewTextBoxColumn.Name = "namabarangDataGridViewTextBoxColumn";
            this.namabarangDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // jumlahbarangDataGridViewTextBoxColumn
            // 
            this.jumlahbarangDataGridViewTextBoxColumn.DataPropertyName = "jumlah_barang";
            this.jumlahbarangDataGridViewTextBoxColumn.HeaderText = "Jumlah Barang";
            this.jumlahbarangDataGridViewTextBoxColumn.Name = "jumlahbarangDataGridViewTextBoxColumn";
            this.jumlahbarangDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // inventarisBarangBindingSource
            // 
            this.inventarisBarangBindingSource.DataMember = "Inventaris Barang";
            this.inventarisBarangBindingSource.DataSource = this.koDingDataSet24;
            // 
            // koDingDataSet24
            // 
            this.koDingDataSet24.DataSetName = "KoDingDataSet24";
            this.koDingDataSet24.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnbatal
            // 
            this.btnbatal.ActiveBorderThickness = 1;
            this.btnbatal.ActiveCornerRadius = 20;
            this.btnbatal.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnbatal.ActiveForecolor = System.Drawing.Color.White;
            this.btnbatal.ActiveLineColor = System.Drawing.Color.Black;
            this.btnbatal.BackColor = System.Drawing.Color.Cyan;
            this.btnbatal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnbatal.BackgroundImage")));
            this.btnbatal.ButtonText = "Batal";
            this.btnbatal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnbatal.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbatal.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnbatal.IdleBorderThickness = 1;
            this.btnbatal.IdleCornerRadius = 20;
            this.btnbatal.IdleFillColor = System.Drawing.Color.White;
            this.btnbatal.IdleForecolor = System.Drawing.Color.Black;
            this.btnbatal.IdleLineColor = System.Drawing.Color.Black;
            this.btnbatal.Location = new System.Drawing.Point(268, 199);
            this.btnbatal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnbatal.Name = "btnbatal";
            this.btnbatal.Size = new System.Drawing.Size(77, 34);
            this.btnbatal.TabIndex = 31;
            this.btnbatal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnbatal.Click += new System.EventHandler(this.btnbatal_Click);
            // 
            // btntambah
            // 
            this.btntambah.ActiveBorderThickness = 1;
            this.btntambah.ActiveCornerRadius = 20;
            this.btntambah.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btntambah.ActiveForecolor = System.Drawing.Color.White;
            this.btntambah.ActiveLineColor = System.Drawing.Color.Black;
            this.btntambah.BackColor = System.Drawing.Color.Cyan;
            this.btntambah.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btntambah.BackgroundImage")));
            this.btntambah.ButtonText = "Tambah";
            this.btntambah.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btntambah.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntambah.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btntambah.IdleBorderThickness = 1;
            this.btntambah.IdleCornerRadius = 20;
            this.btntambah.IdleFillColor = System.Drawing.Color.White;
            this.btntambah.IdleForecolor = System.Drawing.Color.Black;
            this.btntambah.IdleLineColor = System.Drawing.Color.Black;
            this.btntambah.Location = new System.Drawing.Point(185, 199);
            this.btntambah.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btntambah.Name = "btntambah";
            this.btntambah.Size = new System.Drawing.Size(77, 34);
            this.btntambah.TabIndex = 30;
            this.btntambah.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btntambah.Click += new System.EventHandler(this.btntambah_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::bismillah_jadi.Properties.Resources.icons8_coffee_to_go_96;
            this.pictureBox5.Location = new System.Drawing.Point(31, 120);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(18, 18);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 29;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::bismillah_jadi.Properties.Resources.icons8_name_tag_woman_horizontal_96;
            this.pictureBox6.Location = new System.Drawing.Point(31, 85);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(18, 18);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 24;
            this.pictureBox6.TabStop = false;
            // 
            // txttbhnama
            // 
            this.txttbhnama.BackColor = System.Drawing.Color.Cyan;
            this.txttbhnama.BorderColor = System.Drawing.Color.SeaGreen;
            this.txttbhnama.Location = new System.Drawing.Point(189, 120);
            this.txttbhnama.MaxLength = 50;
            this.txttbhnama.Name = "txttbhnama";
            this.txttbhnama.Size = new System.Drawing.Size(155, 20);
            this.txttbhnama.TabIndex = 14;
            this.txttbhnama.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txttbhnama_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(171, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(12, 18);
            this.label9.TabIndex = 13;
            this.label9.Text = ":";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(171, 120);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(12, 18);
            this.label10.TabIndex = 12;
            this.label10.Text = ":";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(55, 120);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 18);
            this.label11.TabIndex = 1;
            this.label11.Text = "Nama Barang";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(55, 85);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 18);
            this.label12.TabIndex = 0;
            this.label12.Text = "ID Barang";
            // 
            // perbaruibahan
            // 
            this.perbaruibahan.BackColor = System.Drawing.Color.Cyan;
            this.perbaruibahan.Controls.Add(this.pictureBox4);
            this.perbaruibahan.Controls.Add(this.bunifuCustomTextbox2);
            this.perbaruibahan.Controls.Add(this.label7);
            this.perbaruibahan.Controls.Add(this.label8);
            this.perbaruibahan.Controls.Add(this.txtupdateid);
            this.perbaruibahan.Controls.Add(this.update);
            this.perbaruibahan.Controls.Add(this.btndelete);
            this.perbaruibahan.Controls.Add(this.btnupdate);
            this.perbaruibahan.Controls.Add(this.pictureBox1);
            this.perbaruibahan.Controls.Add(this.pictureBox2);
            this.perbaruibahan.Controls.Add(this.txtupdatenama);
            this.perbaruibahan.Controls.Add(this.label1);
            this.perbaruibahan.Controls.Add(this.label2);
            this.perbaruibahan.Controls.Add(this.label3);
            this.perbaruibahan.Controls.Add(this.label4);
            this.perbaruibahan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.perbaruibahan.Location = new System.Drawing.Point(0, 47);
            this.perbaruibahan.Name = "perbaruibahan";
            this.perbaruibahan.Size = new System.Drawing.Size(586, 374);
            this.perbaruibahan.TabIndex = 69;
            this.perbaruibahan.Visible = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::bismillah_jadi.Properties.Resources.icons8_fridge_96;
            this.pictureBox4.Location = new System.Drawing.Point(29, 157);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(18, 18);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 42;
            this.pictureBox4.TabStop = false;
            // 
            // bunifuCustomTextbox2
            // 
            this.bunifuCustomTextbox2.BackColor = System.Drawing.Color.Cyan;
            this.bunifuCustomTextbox2.BorderColor = System.Drawing.Color.SeaGreen;
            this.bunifuCustomTextbox2.Location = new System.Drawing.Point(187, 157);
            this.bunifuCustomTextbox2.MaxLength = 50;
            this.bunifuCustomTextbox2.Name = "bunifuCustomTextbox2";
            this.bunifuCustomTextbox2.Size = new System.Drawing.Size(155, 20);
            this.bunifuCustomTextbox2.TabIndex = 41;
            this.bunifuCustomTextbox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.bunifuCustomTextbox1_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(169, 157);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(12, 18);
            this.label7.TabIndex = 40;
            this.label7.Text = ":";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(53, 157);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 18);
            this.label8.TabIndex = 39;
            this.label8.Text = "Jumlah Barang";
            // 
            // txtupdateid
            // 
            this.txtupdateid.BackColor = System.Drawing.Color.Cyan;
            this.txtupdateid.DataSource = this.inventarisBarangBindingSource;
            this.txtupdateid.DisplayMember = "id_inventaris";
            this.txtupdateid.FormattingEnabled = true;
            this.txtupdateid.Location = new System.Drawing.Point(186, 85);
            this.txtupdateid.Name = "txtupdateid";
            this.txtupdateid.Size = new System.Drawing.Size(154, 21);
            this.txtupdateid.TabIndex = 34;
            this.txtupdateid.ValueMember = "id_inventaris";
            this.txtupdateid.SelectedIndexChanged += new System.EventHandler(this.txtupdateid_SelectedIndexChanged);
            // 
            // update
            // 
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.update.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.update.AutoGenerateColumns = false;
            this.update.BackgroundColor = System.Drawing.Color.LightCyan;
            this.update.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.update.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.update.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.update.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.update.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idinventarisDataGridViewTextBoxColumn1,
            this.namabarangDataGridViewTextBoxColumn1,
            this.jumlahbarangDataGridViewTextBoxColumn1});
            this.update.DataSource = this.inventarisBarangBindingSource;
            this.update.DoubleBuffered = true;
            this.update.EnableHeadersVisualStyles = false;
            this.update.GridColor = System.Drawing.Color.DarkSlateGray;
            this.update.HeaderBgColor = System.Drawing.Color.LightSeaGreen;
            this.update.HeaderForeColor = System.Drawing.Color.Black;
            this.update.Location = new System.Drawing.Point(361, 85);
            this.update.Name = "update";
            this.update.ReadOnly = true;
            this.update.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.update.Size = new System.Drawing.Size(213, 148);
            this.update.TabIndex = 33;
            // 
            // idinventarisDataGridViewTextBoxColumn1
            // 
            this.idinventarisDataGridViewTextBoxColumn1.DataPropertyName = "id_inventaris";
            this.idinventarisDataGridViewTextBoxColumn1.HeaderText = "ID Inventaris";
            this.idinventarisDataGridViewTextBoxColumn1.Name = "idinventarisDataGridViewTextBoxColumn1";
            this.idinventarisDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // namabarangDataGridViewTextBoxColumn1
            // 
            this.namabarangDataGridViewTextBoxColumn1.DataPropertyName = "nama_barang";
            this.namabarangDataGridViewTextBoxColumn1.HeaderText = "Nama Barang";
            this.namabarangDataGridViewTextBoxColumn1.Name = "namabarangDataGridViewTextBoxColumn1";
            this.namabarangDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // jumlahbarangDataGridViewTextBoxColumn1
            // 
            this.jumlahbarangDataGridViewTextBoxColumn1.DataPropertyName = "jumlah_barang";
            this.jumlahbarangDataGridViewTextBoxColumn1.HeaderText = "Jumlah Barang";
            this.jumlahbarangDataGridViewTextBoxColumn1.Name = "jumlahbarangDataGridViewTextBoxColumn1";
            this.jumlahbarangDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // btndelete
            // 
            this.btndelete.ActiveBorderThickness = 1;
            this.btndelete.ActiveCornerRadius = 20;
            this.btndelete.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btndelete.ActiveForecolor = System.Drawing.Color.White;
            this.btndelete.ActiveLineColor = System.Drawing.Color.Black;
            this.btndelete.BackColor = System.Drawing.Color.Cyan;
            this.btndelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btndelete.BackgroundImage")));
            this.btndelete.ButtonText = "Hapus";
            this.btndelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndelete.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelete.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btndelete.IdleBorderThickness = 1;
            this.btndelete.IdleCornerRadius = 20;
            this.btndelete.IdleFillColor = System.Drawing.Color.White;
            this.btndelete.IdleForecolor = System.Drawing.Color.Black;
            this.btndelete.IdleLineColor = System.Drawing.Color.Black;
            this.btndelete.Location = new System.Drawing.Point(268, 195);
            this.btndelete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(77, 34);
            this.btndelete.TabIndex = 31;
            this.btndelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.ActiveBorderThickness = 1;
            this.btnupdate.ActiveCornerRadius = 20;
            this.btnupdate.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnupdate.ActiveForecolor = System.Drawing.Color.White;
            this.btnupdate.ActiveLineColor = System.Drawing.Color.Black;
            this.btnupdate.BackColor = System.Drawing.Color.Cyan;
            this.btnupdate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnupdate.BackgroundImage")));
            this.btnupdate.ButtonText = "Perbarui";
            this.btnupdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnupdate.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnupdate.IdleBorderThickness = 1;
            this.btnupdate.IdleCornerRadius = 20;
            this.btnupdate.IdleFillColor = System.Drawing.Color.White;
            this.btnupdate.IdleForecolor = System.Drawing.Color.Black;
            this.btnupdate.IdleLineColor = System.Drawing.Color.Black;
            this.btnupdate.Location = new System.Drawing.Point(185, 195);
            this.btnupdate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(77, 34);
            this.btnupdate.TabIndex = 30;
            this.btnupdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::bismillah_jadi.Properties.Resources.icons8_coffee_to_go_96;
            this.pictureBox1.Location = new System.Drawing.Point(31, 120);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(18, 18);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::bismillah_jadi.Properties.Resources.icons8_name_tag_woman_horizontal_96;
            this.pictureBox2.Location = new System.Drawing.Point(31, 85);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(18, 18);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 24;
            this.pictureBox2.TabStop = false;
            // 
            // txtupdatenama
            // 
            this.txtupdatenama.BackColor = System.Drawing.Color.Cyan;
            this.txtupdatenama.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtupdatenama.Location = new System.Drawing.Point(186, 120);
            this.txtupdatenama.MaxLength = 50;
            this.txtupdatenama.Name = "txtupdatenama";
            this.txtupdatenama.Size = new System.Drawing.Size(155, 20);
            this.txtupdatenama.TabIndex = 14;
            this.txtupdatenama.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txttbhnama_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(171, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(12, 18);
            this.label1.TabIndex = 13;
            this.label1.Text = ":";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(171, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(12, 18);
            this.label2.TabIndex = 12;
            this.label2.Text = ":";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(55, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 18);
            this.label3.TabIndex = 1;
            this.label3.Text = "Nama Barang";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(55, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 18);
            this.label4.TabIndex = 0;
            this.label4.Text = "ID Barang";
            // 
            // inventaris_BarangTableAdapter
            // 
            this.inventaris_BarangTableAdapter.ClearBeforeFill = true;
            // 
            // CRUD_Inventaris
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.Controls.Add(this.perbaruibahan);
            this.Controls.Add(this.tambahbahan);
            this.Controls.Add(this.panel1);
            this.Name = "CRUD_Inventaris";
            this.Size = new System.Drawing.Size(586, 421);
            this.Load += new System.EventHandler(this.CRUD_Inventaris_Load);
            this.panel1.ResumeLayout(false);
            this.tambahbahan.ResumeLayout(false);
            this.tambahbahan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventarisBarangBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.koDingDataSet24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.perbaruibahan.ResumeLayout(false);
            this.perbaruibahan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.update)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuFlatButton btnperbaruibahan;
        private Bunifu.Framework.UI.BunifuFlatButton btntambahbahan;
        private System.Windows.Forms.Panel tambahbahan;
        private Bunifu.Framework.BunifuCustomTextbox txttbhid;
        private Bunifu.Framework.UI.BunifuCustomDataGrid bunifuCustomDataGrid3;
        private Bunifu.Framework.UI.BunifuThinButton2 btnbatal;
        private Bunifu.Framework.UI.BunifuThinButton2 btntambah;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private Bunifu.Framework.BunifuCustomTextbox txttbhnama;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox3;
        private Bunifu.Framework.BunifuCustomTextbox bunifuCustomTextbox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel perbaruibahan;
        private System.Windows.Forms.ComboBox txtupdateid;
        private Bunifu.Framework.UI.BunifuCustomDataGrid update;
        private Bunifu.Framework.UI.BunifuThinButton2 btndelete;
        private Bunifu.Framework.UI.BunifuThinButton2 btnupdate;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Bunifu.Framework.BunifuCustomTextbox txtupdatenama;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridViewTextBoxColumn idinventarisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn namabarangDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn jumlahbarangDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource inventarisBarangBindingSource;
        private KoDingDataSet24 koDingDataSet24;
        private KoDingDataSet24TableAdapters.Inventaris_BarangTableAdapter inventaris_BarangTableAdapter;
        private System.Windows.Forms.PictureBox pictureBox4;
        private Bunifu.Framework.BunifuCustomTextbox bunifuCustomTextbox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridViewTextBoxColumn idinventarisDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn namabarangDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn jumlahbarangDataGridViewTextBoxColumn1;
    }
}
