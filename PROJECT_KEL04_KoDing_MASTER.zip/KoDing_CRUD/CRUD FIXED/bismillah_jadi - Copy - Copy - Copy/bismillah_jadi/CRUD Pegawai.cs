﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace bismillah_jadi
{
    public partial class CRUD_Pegawai : UserControl
    {
        public CRUD_Pegawai()
        {
            InitializeComponent();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();


            try
            {
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox7.Text == "" || textBox9.Text == "" || comboBox1.Text == "" || comboBox1.Text == "---Pilih Golongan---")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
               

                else if (EmailIsValid(textBox5.Text) == false)
                {
                    MessageBox.Show("Format Email Tidak Sesuai! Contoh : a@b.c", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (bunifuDatepicker1.Value == DateTime.Now)
                {
                    MessageBox.Show("Format Tanggal Lahir Harus Kurang Dari Hari Ini", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }


                else
                {

                    SqlCommand insert = new SqlCommand("sp_InsertPegawai", connection);
                    insert.CommandType = CommandType.StoredProcedure;

                    insert.Parameters.AddWithValue("@id_pegawai", textBox1.Text);
                    insert.Parameters.AddWithValue("@nama_pegawai", textBox2.Text);
                    insert.Parameters.AddWithValue("@no_telepon", textBox3.Text);
                    insert.Parameters.AddWithValue("@alamat", textBox4.Text);
                    insert.Parameters.AddWithValue("@email", textBox5.Text);
                    insert.Parameters.AddWithValue("@tanggal_lahir", bunifuDatepicker1.Value);
                    insert.Parameters.AddWithValue("@role", textBox7.Text);
                    insert.Parameters.AddWithValue("@password", textBox9.Text);
                    insert.Parameters.AddWithValue("@id_golongan", comboBox1.SelectedValue);
                    int numRes = insert.ExecuteNonQuery();
                    if (numRes > 0)
                    {
                        MessageBox.Show("Data Pegawai Berhasil Disimpan!");
                        clear();
                        Refreshdata();

                        string query = "select id_pegawai from Pegawai order by id_pegawai desc";
                        textBox1.Text = autoNumber("PGW-", query);
                    }
                    else
                        MessageBox.Show("Gagal Menyimpan! Coba Lagi!");
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void clear()
        {
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            bunifuDatepicker1.Value = DateTime.Now;
            textBox7.Text = "";
            textBox9.Text = "";
            comboBox1.Text = "---Pilih ID Golongan---";
        }

        private void Refreshdata()
        {

            this.pegawaiTableAdapter.Fill(this.koDingDataSet16.Pegawai);
        }

        private string autoNumber(string firstText, string query)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            string result = "";
            int num = 0;
            try
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;

        }

        private void CRUD_Pegawai_Load(object sender, EventArgs e)
        {
            string query = "select id_pegawai from Pegawai order by id_pegawai desc";
            textBox1.Text = autoNumber("PGW-", query);

            comboBox1.Text = "---Pilih Golongan---";
            textBox9.Text = "KoDing_123";

            this.golongan_GajiTableAdapter.Fill(this.koDingDataSet17.Golongan_Gaji);
            this.pegawaiTableAdapter.Fill(this.koDingDataSet16.Pegawai);
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsLetter(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsLetter(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsDigit(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        public static bool EmailIsValid(string email)
        {
            string regexPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$";

            if (Regex.IsMatch(email, regexPattern))
            {
                if (Regex.Replace(email, regexPattern, string.Empty).Length == 0)
                {
                    return true;
                }
            }
            return false;
        }

        private void btnperbarui_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();


            try
            {
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox7.Text == "" || textBox9.Text == "" || comboBox1.Text == "" || comboBox1.Text == "---Pilih Golongan---")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                else if (EmailIsValid(textBox5.Text) == false)
                {
                    MessageBox.Show("Format Email Tidak Sesuai! Contoh : a@b.c", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    SqlCommand insert = new SqlCommand("sp_UpdatePegawai", connection);
                    insert.CommandType = CommandType.StoredProcedure;

                    insert.Parameters.AddWithValue("@id_pegawai", textBox1.Text);
                    insert.Parameters.AddWithValue("@nama_pegawai", textBox2.Text);
                    insert.Parameters.AddWithValue("@no_telepon", textBox3.Text);
                    insert.Parameters.AddWithValue("@alamat", textBox4.Text);
                    insert.Parameters.AddWithValue("@email", textBox5.Text);
                    insert.Parameters.AddWithValue("@tanggal_lahir", bunifuDatepicker1.Value);
                    insert.Parameters.AddWithValue("@role", textBox7.Text);
                    insert.Parameters.AddWithValue("@password", textBox9.Text);
                    insert.Parameters.AddWithValue("@id_golongan", comboBox1.SelectedValue);
                    int numRes = insert.ExecuteNonQuery();
                    if (numRes > 0)
                    {
                        MessageBox.Show("Data Pegawai Berhasil Diperbarui!");
                        clear();
                        Refreshdata();

                        string query = "select id_pegawai from Pegawai order by id_pegawai desc";
                        textBox1.Text = autoNumber("PGW-", query);
                    }
                    else
                    {
                        MessageBox.Show("Gagal Memperbarui! Coba Lagi!");
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void hapus_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();


            try
            {
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == ""  || textBox7.Text == "" || textBox9.Text == "" || comboBox1.Text == "" || comboBox1.Text == "---Pilih Golongan---")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string message = "Hapus Data??";
                    string title = "Confirmation";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result = MessageBox.Show(message, title, buttons);
                    if (result == DialogResult.Yes)
                    {

                        SqlCommand delete = new SqlCommand("sp_DeletePegawai", connection);
                        delete.CommandType = CommandType.StoredProcedure;

                        delete.Parameters.AddWithValue("@id_pegawai", textBox1.Text);
                        
                        int numRes = delete.ExecuteNonQuery();
                        if (numRes >= 0)
                        {
                            MessageBox.Show("Data Pegawai Berhasil Dihapus!", "Infomation!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            Refreshdata();
                            clear();
                            string query = "select id_pegawai from Pegawai order by id_pegawai desc";
                            textBox1.Text = autoNumber("PGW-", query);
                        }
                        else
                            MessageBox.Show("Gagal Menghapus! Coba Lagi!");
                    }
                    else
                    {
                        clear();
                    }
                   
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                if (cek(textBox1.Text) == false)
                {
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    bunifuDatepicker1.Value = DateTime.Now;
                    textBox7.Text = "";
                    textBox9.Text = "";
                    comboBox1.Text = "";
                }
            }

        }

        private Boolean cek(string id)
        {


            id = id.ToUpper();
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            SqlCommand dbcmd = connection.CreateCommand();
            string sql = "select * from Pegawai where id_pegawai='" + textBox1.Text + "'";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();

            while (reader.Read())
            {
                if ((reader.GetString(0).ToString().ToUpper() == id))
                {
                    textBox2.Text = reader.GetValue(1).ToString();
                    textBox3.Text = reader.GetValue(2).ToString();
                    textBox4.Text = reader.GetValue(3).ToString();
                    textBox5.Text = reader.GetValue(4).ToString();
                    string ttl = reader.GetValue(5).ToString();
                    bunifuDatepicker1.Value = Convert.ToDateTime(ttl);
                    textBox7.Text = reader.GetValue(6).ToString();
                    textBox9.Text = reader.GetValue(7).ToString();
                    comboBox1.Text = reader.GetValue(8).ToString();
                    return true;
                }
            }
            connection.Close();
            return false;
        }
    }
}
