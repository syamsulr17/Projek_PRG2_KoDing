﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace bismillah_jadi
{
    public partial class CRUD_Member : UserControl
    {
        public CRUD_Member()
        {
            InitializeComponent();
        }

        private void notelp_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void btnperbaruibahan_Click(object sender, EventArgs e)
        {
            
        }

        private void CRUD_Member_Load(object sender, EventArgs e)
        {
            this.golongan_MemberTableAdapter.Fill(this.koDingDataSet27.Golongan_Member);
            txtid.Text = "MBR-0";
        }

        private void btnperbarui_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            try
            {
                if (txtid.Text == "" || txtnama.Text == "" || txtnotelp.Text == "" || txtalamat.Text == "" || txtemail.Text == "" || comboBox1.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (EmailIsValid(txtemail.Text) == false)
                    {
                        MessageBox.Show("Format Email Salah!, Contoh : a@b.c", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                else
                {
                    SqlCommand update = new SqlCommand("sp_UpdateMember", connection);
                    update.CommandType = CommandType.StoredProcedure;

                    update.Parameters.AddWithValue("@id_member", txtid.Text);
                    update.Parameters.AddWithValue("@nama_member", txtnama.Text);
                    update.Parameters.AddWithValue("@no_telepon", txtnotelp.Text);
                    update.Parameters.AddWithValue("@email", txtemail.Text);
                    update.Parameters.AddWithValue("@alamat", txtalamat.Text);
                    update.Parameters.AddWithValue("@tanggal_pendaftaran", datelahir.Value);
                    update.Parameters.AddWithValue("@id_golongan_member", comboBox1.Text);
                    update.ExecuteNonQuery();

                    MessageBox.Show("Berhasil Memperbarui Data Member!", "Information!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        clear();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void btnprbruibatal_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            try
            {
                
                    if (txtid.Text == "" || txtnama.Text == "" || txtnotelp.Text == "" || txtalamat.Text == "" || txtemail.Text == "" || comboBox1.Text == "")
                    {
                        MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        string message = "Hapus Data??";
                        string title = "Confirmation";
                        MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                        DialogResult result = MessageBox.Show(message, title, buttons);
                        if (result == DialogResult.Yes)
                        {

                        SqlCommand delete = new SqlCommand("sp_DeleteMember", connection);
                        delete.CommandType = CommandType.StoredProcedure;

                        delete.Parameters.AddWithValue("@id_member", txtid.Text);
                        int numRes = delete.ExecuteNonQuery();
                        if (numRes >= 0)
                        {
                            MessageBox.Show("Data Member Berhasil Dihapus!", "Infomation!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            clear();

                        }
                        else
                            MessageBox.Show("Gagal Menghapus! Coba Lagi!");
                        }
                        else
                        {
                            clear();
                        }

                    }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void clear()
        {
            txtnama.Text = "";
            txtnotelp.Text = "";
            txtalamat.Text = "";
            txtemail.Text = "";
            datelahir.Value = DateTime.Now;
        }

       
        private void txtnotelp_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsDigit(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        public static bool EmailIsValid(string email)
        {
            string regexPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$";

            if (Regex.IsMatch(email, regexPattern))
            {
                if (Regex.Replace(email, regexPattern, string.Empty).Length == 0)
                {
                    return true;
                }
            }
            return false;
        }

        private void txtid_TextChanged(object sender, EventArgs e)
        {
            
            if (txtid.Text != "")
            {
                if (cek(txtid.Text) == false)
                {
                    txtnama.Text = "";
                    txtnotelp.Text = "";
                    txtalamat.Text = "";
                    datelahir.Value = DateTime.Now;
                    txtemail.Text = "";
                }
            }
           
            
        }
        private Boolean cek(string id)
        {


            id = id.ToUpper();
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            SqlCommand dbcmd = connection.CreateCommand();
            string sql = "select * from [dbo].[Member] where id_member='" + txtid.Text + "'";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();

            while (reader.Read())
            {
                if ((reader.GetString(0).ToString().ToUpper() == id))
                {
                    txtnama.Enabled = true;
                    txtnotelp.Enabled = true;
                    txtalamat.Enabled = true;
                    datelahir.Enabled = true;
                    txtemail.Enabled = true;
                    txtnama.Text = reader.GetValue(1).ToString();
                    txtnotelp.Text = reader.GetValue(2).ToString();
                    txtalamat.Text = reader.GetValue(4).ToString();
                    string date = reader.GetValue(5).ToString();
                    datelahir.Value = Convert.ToDateTime(date);
                    txtemail.Text = reader.GetValue(3).ToString();
                    comboBox1.Text = reader.GetValue(6).ToString();
                    return true;
                }
            }
            connection.Close();
            return false;
        }

        private void txtnama_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsLetter(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
