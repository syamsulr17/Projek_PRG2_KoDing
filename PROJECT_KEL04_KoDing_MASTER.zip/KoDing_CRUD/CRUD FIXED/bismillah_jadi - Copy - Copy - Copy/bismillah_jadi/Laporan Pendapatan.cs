﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bismillah_jadi
{
    public partial class Laporan_Pendapatan : UserControl
    {
        public Laporan_Pendapatan()
        {
            InitializeComponent();
        }

        private void bunifuCustomDataGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bunifuDataViz1_Load(object sender, EventArgs e)
        {
            var r = new Random();

            var canvas = new Bunifu.DataViz.WinForms.Canvas();
            var datapoint = new Bunifu.DataViz.WinForms.DataPoint(Bunifu.DataViz.WinForms.BunifuDataViz._type.Bunifu_line);
            datapoint.addLabely("JAN", r.Next(0, 100).ToString());

            datapoint.addLabely("FEB", r.Next(0, 100).ToString());

            datapoint.addLabely("MARCH", r.Next(0, 100).ToString());

            datapoint.addLabely("APR", r.Next(0, 100).ToString());

            datapoint.addLabely("MAY", r.Next(0, 100).ToString());

            datapoint.addLabely("JUNE", r.Next(0, 100).ToString());

            datapoint.addLabely("JULY", r.Next(0, 100).ToString());

            datapoint.addLabely("AUG", r.Next(0, 100).ToString());
            datapoint.addLabely("SEP", r.Next(0, 100).ToString());
            datapoint.addLabely("OCT", r.Next(0, 100).ToString());
            datapoint.addLabely("NOV", r.Next(0, 100).ToString());
            datapoint.addLabely("DEC", r.Next(0, 100).ToString());
            canvas.addData(datapoint);
            bunifuDataViz1.Render(canvas);
        }
    }
}
