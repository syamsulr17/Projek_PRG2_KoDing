﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bismillah_jadi
{
    public partial class Admin : Form
    {
        //Bunifu.DataViz.WinForms.DataPoint DataPoint1;


        public Admin()
        {
            InitializeComponent();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            var r = new Random();

            var canvas = new Bunifu.DataViz.WinForms.Canvas();
            var canvas1 = new Bunifu.DataViz.WinForms.Canvas();
            var canvas2 = new Bunifu.DataViz.WinForms.Canvas();

            var datapoint = new Bunifu.DataViz.WinForms.DataPoint(Bunifu.DataViz.WinForms.BunifuDataViz._type.Bunifu_line);
            var datapoint1= new Bunifu.DataViz.WinForms.DataPoint(Bunifu.DataViz.WinForms.BunifuDataViz._type.Bunifu_column);
            var datapoint2 = new Bunifu.DataViz.WinForms.DataPoint(Bunifu.DataViz.WinForms.BunifuDataViz._type.Bunifu_bar);

            datapoint.addLabely("JAN", r.Next(0, 100).ToString());

            datapoint.addLabely("FEB", r.Next(0, 100).ToString());

            datapoint.addLabely("MARCH", r.Next(0, 100).ToString());

            datapoint.addLabely("APR", r.Next(0, 100).ToString());

            datapoint.addLabely("MAY", r.Next(0, 100).ToString());

            datapoint.addLabely("JUNE", r.Next(0, 100).ToString());

            datapoint.addLabely("JULY", r.Next(0, 100).ToString());

            datapoint.addLabely("AUG", r.Next(0, 100).ToString());
            datapoint.addLabely("SEP", r.Next(0, 100).ToString());
            datapoint.addLabely("OCT", r.Next(0, 100).ToString());
            datapoint.addLabely("NOV", r.Next(0, 100).ToString());
            datapoint.addLabely("DEC", r.Next(0, 100).ToString());

            datapoint1.addLabely("JAN", r.Next(0, 100).ToString());

            datapoint1.addLabely("FEB", r.Next(0, 100).ToString());

            datapoint1.addLabely("MARCH", r.Next(0, 100).ToString());

            datapoint1.addLabely("APR", r.Next(0, 100).ToString());

            datapoint1.addLabely("MAY", r.Next(0, 100).ToString());

            datapoint1.addLabely("JUNE", r.Next(0, 100).ToString());

            datapoint1.addLabely("JULY", r.Next(0, 100).ToString());

            datapoint1.addLabely("AUG", r.Next(0, 100).ToString());
            datapoint1.addLabely("SEP", r.Next(0, 100).ToString());
            datapoint1.addLabely("OCT", r.Next(0, 100).ToString());
            datapoint1.addLabely("NOV", r.Next(0, 100).ToString());
            datapoint1.addLabely("DEC", r.Next(0, 100).ToString());

            datapoint2.addLabely("JAN", r.Next(0, 100).ToString());

            datapoint2.addLabely("FEB", r.Next(0, 100).ToString());

            datapoint2.addLabely("MARCH", r.Next(0, 100).ToString());

            datapoint2.addLabely("APR", r.Next(0, 100).ToString());

            datapoint2.addLabely("MAY", r.Next(0, 100).ToString());

            datapoint2.addLabely("JUNE", r.Next(0, 100).ToString());

            datapoint2.addLabely("JULY", r.Next(0, 100).ToString());

            datapoint2.addLabely("AUG", r.Next(0, 100).ToString());
            datapoint2.addLabely("SEP", r.Next(0, 100).ToString());
            datapoint2.addLabely("OCT", r.Next(0, 100).ToString());
            datapoint2.addLabely("NOV", r.Next(0, 100).ToString());
            datapoint2.addLabely("DEC", r.Next(0, 100).ToString());


            // Add data sets to canvas

            canvas.addData(datapoint);
            canvas1.addData(datapoint1);
            canvas2.addData(datapoint2);

            //render canvas

            bunifuDataViz1.Render(canvas);
            bunifuDataViz2.Render(canvas2);
            bunifuDataViz4.Render(canvas1);



        }

        private void bunifuDataViz1_Load(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuDataViz2_Load(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            btnhome.Visible = false;
            btnabout.Visible = false;

            
        }

        private void k_pegawai_Click(object sender, EventArgs e)
        {
            cruD_Pegawai1.Visible = true;
            CRUD_Daftar_Menu.Visible = false;
        }

        CRUD_Daftar_Menu CRUD_Daftar_Menu = new CRUD_Daftar_Menu();
        private void k_gol_Click(object sender, EventArgs e)
        {
            cruD_Pegawai1.Visible = false;
            CRUD_Daftar_Menu.Visible = true;
        }
    }
}
