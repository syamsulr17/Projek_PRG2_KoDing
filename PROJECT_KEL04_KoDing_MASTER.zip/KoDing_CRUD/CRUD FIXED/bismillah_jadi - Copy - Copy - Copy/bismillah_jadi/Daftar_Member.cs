﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using Bunifu.Framework.UI;

namespace bismillah_jadi
{
    public partial class Daftar_Member : UserControl
    {
        public Daftar_Member()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            
        }
        

        private void btndaftar_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            try
            {
                if (idmember.Text == "" || namamember.Text == "" || bunifuCustomTextbox1.Text == "" || alamat.Text == "")
                {
                    MessageBox.Show("Semua Data Wajib Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (EmailIsValid(email.Text) == false)
                {
                    MessageBox.Show("Format Email Salah!, Contoh : a@b.c", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                else
                {
                    SqlCommand insert = new SqlCommand("sp_InsertMember", connection);
                    insert.CommandType = CommandType.StoredProcedure;

                    insert.Parameters.AddWithValue("@id_member", idmember.Text);
                    insert.Parameters.AddWithValue("@nama_member", namamember.Text);
                    insert.Parameters.AddWithValue("@no_telepon", bunifuCustomTextbox1.Text);
                    insert.Parameters.AddWithValue("@email", email.Text);
                    insert.Parameters.AddWithValue("@alamat", alamat.Text);
                    insert.Parameters.AddWithValue("@tanggal_pendaftaran", tgllahir.Value);
                    insert.Parameters.AddWithValue("@id_golongan_member", comboBox1.Text);
                    int numRes = insert.ExecuteNonQuery();
                    if (numRes > 0)
                    {
                        MessageBox.Show("Data Member Berhasil Disimpan!");
                        clear();

                        string query = "select id_member from [dbo].[Member] order by id_member desc";
                        idmember.Text = autoNumber("MBR-", query);
                    }
                    else
                        MessageBox.Show("Gagal Menyimpan! Coba Lagi!");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private string autoNumber(string firstText, string query)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            string result = "";
            int num = 0;
            try
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;

        }

        private void btnbatal_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void email_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void Daftar_Member_Load(object sender, EventArgs e)
        {
            string query = "select id_member from [dbo].[Member] order by id_member desc";
            idmember.Text = autoNumber("MBR-", query);

            this.golongan_MemberTableAdapter1.Fill(this.koDingDataSet23.Golongan_Member);
            comboBox1.Text = "---Pilih ID Golongan---";
        }

        private void bunifuCustomTextbox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void bunifuCustomTextbox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsDigit(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        public static bool EmailIsValid(string email)
        {
            string regexPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$";

            if (Regex.IsMatch(email, regexPattern))
            {
                if (Regex.Replace(email, regexPattern, string.Empty).Length == 0)
                {
                    return true;
                }
            }
            return false;
        }

        public void clear()
        {
            
            namamember.Clear();
            bunifuCustomTextbox1.Clear();
            alamat.Clear();
            email.Clear();
            tgllahir.Value = DateTime.Now;
        }

        private void namamember_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsLetter(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}

