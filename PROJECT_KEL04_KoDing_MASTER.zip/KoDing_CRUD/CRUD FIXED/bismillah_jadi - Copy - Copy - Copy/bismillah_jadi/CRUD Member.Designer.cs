﻿namespace bismillah_jadi
{
    partial class CRUD_Member
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CRUD_Member));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.txtnama = new Bunifu.Framework.BunifuCustomTextbox();
            this.datelahir = new Bunifu.Framework.UI.BunifuDatepicker();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtemail = new Bunifu.Framework.BunifuCustomTextbox();
            this.txtalamat = new Bunifu.Framework.BunifuCustomTextbox();
            this.txtnotelp = new Bunifu.Framework.BunifuCustomTextbox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnprbruibatal = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnperbarui = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtid = new Bunifu.Framework.BunifuCustomTextbox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.koDingDataSet27 = new bismillah_jadi.KoDingDataSet27();
            this.golonganMemberBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.golongan_MemberTableAdapter = new bismillah_jadi.KoDingDataSet27TableAdapters.Golongan_MemberTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.koDingDataSet27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.golonganMemberBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkCyan;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(586, 47);
            this.panel1.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(79, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(157, 18);
            this.label7.TabIndex = 1;
            this.label7.Text = "Perbarui Data Member";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::bismillah_jadi.Properties.Resources.icons8_update_96;
            this.pictureBox7.Location = new System.Drawing.Point(0, 0);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(73, 47);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            // 
            // txtnama
            // 
            this.txtnama.BackColor = System.Drawing.Color.Cyan;
            this.txtnama.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtnama.Enabled = false;
            this.txtnama.ForeColor = System.Drawing.Color.Black;
            this.txtnama.Location = new System.Drawing.Point(248, 98);
            this.txtnama.MaxLength = 20;
            this.txtnama.Name = "txtnama";
            this.txtnama.Size = new System.Drawing.Size(248, 20);
            this.txtnama.TabIndex = 57;
            this.txtnama.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnama_KeyPress);
            // 
            // datelahir
            // 
            this.datelahir.BackColor = System.Drawing.Color.CadetBlue;
            this.datelahir.BorderRadius = 0;
            this.datelahir.Enabled = false;
            this.datelahir.ForeColor = System.Drawing.Color.Black;
            this.datelahir.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.datelahir.FormatCustom = null;
            this.datelahir.Location = new System.Drawing.Point(248, 245);
            this.datelahir.Name = "datelahir";
            this.datelahir.Size = new System.Drawing.Size(248, 32);
            this.datelahir.TabIndex = 56;
            this.datelahir.Value = new System.DateTime(2020, 4, 12, 11, 48, 41, 368);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::bismillah_jadi.Properties.Resources.icons8_name_96;
            this.pictureBox6.Location = new System.Drawing.Point(90, 98);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(18, 18);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 55;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::bismillah_jadi.Properties.Resources.icons8_cell_phone_96;
            this.pictureBox5.Location = new System.Drawing.Point(90, 137);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(18, 18);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 54;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::bismillah_jadi.Properties.Resources.icons8_home_address_96;
            this.pictureBox4.Location = new System.Drawing.Point(90, 175);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(18, 18);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 53;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::bismillah_jadi.Properties.Resources.icons8_calendar_96;
            this.pictureBox3.Location = new System.Drawing.Point(90, 245);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(18, 18);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 52;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::bismillah_jadi.Properties.Resources.icons8_email_open_96;
            this.pictureBox2.Location = new System.Drawing.Point(90, 299);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(18, 18);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 51;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::bismillah_jadi.Properties.Resources.icons8_name_tag_woman_horizontal_96;
            this.pictureBox1.Location = new System.Drawing.Point(90, 63);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(18, 18);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 50;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(114, 243);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 18);
            this.label4.TabIndex = 35;
            this.label4.Text = "Tanggal Lahir";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(230, 243);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(12, 18);
            this.label8.TabIndex = 38;
            this.label8.Text = ":";
            // 
            // txtemail
            // 
            this.txtemail.BackColor = System.Drawing.Color.Cyan;
            this.txtemail.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtemail.Enabled = false;
            this.txtemail.ForeColor = System.Drawing.Color.Black;
            this.txtemail.Location = new System.Drawing.Point(248, 299);
            this.txtemail.MaxLength = 30;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(248, 20);
            this.txtemail.TabIndex = 46;
            // 
            // txtalamat
            // 
            this.txtalamat.BackColor = System.Drawing.Color.Cyan;
            this.txtalamat.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtalamat.Enabled = false;
            this.txtalamat.ForeColor = System.Drawing.Color.Black;
            this.txtalamat.Location = new System.Drawing.Point(248, 175);
            this.txtalamat.MaxLength = 50;
            this.txtalamat.Multiline = true;
            this.txtalamat.Name = "txtalamat";
            this.txtalamat.Size = new System.Drawing.Size(248, 53);
            this.txtalamat.TabIndex = 45;
            // 
            // txtnotelp
            // 
            this.txtnotelp.BackColor = System.Drawing.Color.Cyan;
            this.txtnotelp.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtnotelp.Enabled = false;
            this.txtnotelp.ForeColor = System.Drawing.Color.Black;
            this.txtnotelp.Location = new System.Drawing.Point(248, 137);
            this.txtnotelp.MaxLength = 13;
            this.txtnotelp.Name = "txtnotelp";
            this.txtnotelp.Size = new System.Drawing.Size(248, 20);
            this.txtnotelp.TabIndex = 44;
            this.txtnotelp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnotelp_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(230, 63);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(12, 18);
            this.label14.TabIndex = 43;
            this.label14.Text = ":";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(230, 98);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(12, 18);
            this.label13.TabIndex = 42;
            this.label13.Text = ":";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(230, 137);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(12, 18);
            this.label12.TabIndex = 41;
            this.label12.Text = ":";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(230, 299);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(12, 18);
            this.label10.TabIndex = 40;
            this.label10.Text = ":";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(230, 175);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(12, 18);
            this.label9.TabIndex = 39;
            this.label9.Text = ":";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(114, 299);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 18);
            this.label6.TabIndex = 37;
            this.label6.Text = "Email";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(114, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 18);
            this.label5.TabIndex = 36;
            this.label5.Text = "Alamat";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(114, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 18);
            this.label3.TabIndex = 34;
            this.label3.Text = "No Telepon";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(114, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 18);
            this.label2.TabIndex = 33;
            this.label2.Text = "Nama Member";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(114, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 18);
            this.label1.TabIndex = 32;
            this.label1.Text = "ID Member";
            // 
            // btnprbruibatal
            // 
            this.btnprbruibatal.ActiveBorderThickness = 1;
            this.btnprbruibatal.ActiveCornerRadius = 20;
            this.btnprbruibatal.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnprbruibatal.ActiveForecolor = System.Drawing.Color.White;
            this.btnprbruibatal.ActiveLineColor = System.Drawing.Color.Black;
            this.btnprbruibatal.BackColor = System.Drawing.Color.Cyan;
            this.btnprbruibatal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnprbruibatal.BackgroundImage")));
            this.btnprbruibatal.ButtonText = "Hapus";
            this.btnprbruibatal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnprbruibatal.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprbruibatal.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnprbruibatal.IdleBorderThickness = 1;
            this.btnprbruibatal.IdleCornerRadius = 20;
            this.btnprbruibatal.IdleFillColor = System.Drawing.Color.White;
            this.btnprbruibatal.IdleForecolor = System.Drawing.Color.Black;
            this.btnprbruibatal.IdleLineColor = System.Drawing.Color.Black;
            this.btnprbruibatal.Location = new System.Drawing.Point(412, 367);
            this.btnprbruibatal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnprbruibatal.Name = "btnprbruibatal";
            this.btnprbruibatal.Size = new System.Drawing.Size(84, 40);
            this.btnprbruibatal.TabIndex = 59;
            this.btnprbruibatal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnprbruibatal.Click += new System.EventHandler(this.btnprbruibatal_Click);
            // 
            // btnperbarui
            // 
            this.btnperbarui.ActiveBorderThickness = 1;
            this.btnperbarui.ActiveCornerRadius = 20;
            this.btnperbarui.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnperbarui.ActiveForecolor = System.Drawing.Color.White;
            this.btnperbarui.ActiveLineColor = System.Drawing.Color.Black;
            this.btnperbarui.BackColor = System.Drawing.Color.Cyan;
            this.btnperbarui.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnperbarui.BackgroundImage")));
            this.btnperbarui.ButtonText = "Perbarui";
            this.btnperbarui.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnperbarui.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnperbarui.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnperbarui.IdleBorderThickness = 1;
            this.btnperbarui.IdleCornerRadius = 20;
            this.btnperbarui.IdleFillColor = System.Drawing.Color.White;
            this.btnperbarui.IdleForecolor = System.Drawing.Color.Black;
            this.btnperbarui.IdleLineColor = System.Drawing.Color.Black;
            this.btnperbarui.Location = new System.Drawing.Point(313, 367);
            this.btnperbarui.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnperbarui.Name = "btnperbarui";
            this.btnperbarui.Size = new System.Drawing.Size(84, 40);
            this.btnperbarui.TabIndex = 58;
            this.btnperbarui.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnperbarui.Click += new System.EventHandler(this.btnperbarui_Click);
            // 
            // txtid
            // 
            this.txtid.BackColor = System.Drawing.Color.Cyan;
            this.txtid.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtid.ForeColor = System.Drawing.Color.Black;
            this.txtid.Location = new System.Drawing.Point(248, 63);
            this.txtid.MaxLength = 10;
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(248, 20);
            this.txtid.TabIndex = 60;
            this.txtid.TextChanged += new System.EventHandler(this.txtid_TextChanged);
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox8.Image = global::bismillah_jadi.Properties.Resources.icons8_name_tag_woman_horizontal_96;
            this.pictureBox8.Location = new System.Drawing.Point(90, 338);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(18, 18);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 85;
            this.pictureBox8.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Cyan;
            this.label11.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(114, 338);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(111, 18);
            this.label11.TabIndex = 84;
            this.label11.Text = "Kategori Member";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Cyan;
            this.label15.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(230, 338);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(12, 18);
            this.label15.TabIndex = 83;
            this.label15.Text = ":";
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.Cyan;
            this.comboBox1.DataSource = this.golonganMemberBindingSource;
            this.comboBox1.DisplayMember = "id_golongan_member";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(248, 335);
            this.comboBox1.MaxLength = 10;
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(248, 21);
            this.comboBox1.TabIndex = 82;
            this.comboBox1.ValueMember = "id_golongan_member";
            // 
            // koDingDataSet27
            // 
            this.koDingDataSet27.DataSetName = "KoDingDataSet27";
            this.koDingDataSet27.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // golonganMemberBindingSource
            // 
            this.golonganMemberBindingSource.DataMember = "Golongan Member";
            this.golonganMemberBindingSource.DataSource = this.koDingDataSet27;
            // 
            // golongan_MemberTableAdapter
            // 
            this.golongan_MemberTableAdapter.ClearBeforeFill = true;
            // 
            // CRUD_Member
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.txtid);
            this.Controls.Add(this.btnprbruibatal);
            this.Controls.Add(this.btnperbarui);
            this.Controls.Add(this.txtnama);
            this.Controls.Add(this.datelahir);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.txtalamat);
            this.Controls.Add(this.txtnotelp);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "CRUD_Member";
            this.Size = new System.Drawing.Size(586, 421);
            this.Load += new System.EventHandler(this.CRUD_Member_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.koDingDataSet27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.golonganMemberBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.BunifuCustomTextbox txtnama;
        private Bunifu.Framework.UI.BunifuDatepicker datelahir;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private Bunifu.Framework.BunifuCustomTextbox txtemail;
        private Bunifu.Framework.BunifuCustomTextbox txtalamat;
        private Bunifu.Framework.BunifuCustomTextbox txtnotelp;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnprbruibatal;
        private Bunifu.Framework.UI.BunifuThinButton2 btnperbarui;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label7;
        private Bunifu.Framework.BunifuCustomTextbox txtid;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.BindingSource golonganMemberBindingSource;
        private KoDingDataSet27 koDingDataSet27;
        private KoDingDataSet27TableAdapters.Golongan_MemberTableAdapter golongan_MemberTableAdapter;
    }
}
