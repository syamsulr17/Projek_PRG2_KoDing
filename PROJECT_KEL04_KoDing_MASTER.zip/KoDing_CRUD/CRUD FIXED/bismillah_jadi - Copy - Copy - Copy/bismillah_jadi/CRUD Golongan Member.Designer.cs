﻿namespace bismillah_jadi
{
    partial class CRUD_Golongan_Member
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CRUD_Golongan_Member));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnperbaruimenu = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btntambahmenu = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Tambahmenu = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.bunifuCustomTextbox4 = new Bunifu.Framework.BunifuCustomTextbox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomTextbox2 = new Bunifu.Framework.BunifuCustomTextbox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomTextbox3 = new Bunifu.Framework.BunifuCustomTextbox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.bunifuCustomDataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.idgolonganmemberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.namagolonganmemberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.biayapendaftaranDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.golonganMemberBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.koDingDataSet22 = new bismillah_jadi.KoDingDataSet22();
            this.btntambhbatal = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btntambah = new Bunifu.Framework.UI.BunifuThinButton2();
            this.golongan_MemberTableAdapter = new bismillah_jadi.KoDingDataSet22TableAdapters.Golongan_MemberTableAdapter();
            this.Perbaruimenu = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomTextbox1 = new Bunifu.Framework.BunifuCustomTextbox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.bunifuCustomDataGrid3 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.idgolonganmemberDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.namagolonganmemberDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.biayapendaftaranDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnprbruibatal = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnperbarui = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.txtperbaruiid = new System.Windows.Forms.ComboBox();
            this.txtperbaruinama = new Bunifu.Framework.BunifuCustomTextbox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.Tambahmenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.golonganMemberBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.koDingDataSet22)).BeginInit();
            this.Perbaruimenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkCyan;
            this.panel1.Controls.Add(this.btnperbaruimenu);
            this.panel1.Controls.Add(this.btntambahmenu);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(586, 47);
            this.panel1.TabIndex = 15;
            // 
            // btnperbaruimenu
            // 
            this.btnperbaruimenu.Active = false;
            this.btnperbaruimenu.Activecolor = System.Drawing.Color.DarkCyan;
            this.btnperbaruimenu.BackColor = System.Drawing.Color.DarkCyan;
            this.btnperbaruimenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnperbaruimenu.BorderRadius = 0;
            this.btnperbaruimenu.ButtonText = "Perbarui";
            this.btnperbaruimenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnperbaruimenu.DisabledColor = System.Drawing.Color.Gray;
            this.btnperbaruimenu.Iconcolor = System.Drawing.Color.Transparent;
            this.btnperbaruimenu.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnperbaruimenu.Iconimage")));
            this.btnperbaruimenu.Iconimage_right = null;
            this.btnperbaruimenu.Iconimage_right_Selected = null;
            this.btnperbaruimenu.Iconimage_Selected = null;
            this.btnperbaruimenu.IconMarginLeft = 0;
            this.btnperbaruimenu.IconMarginRight = 0;
            this.btnperbaruimenu.IconRightVisible = true;
            this.btnperbaruimenu.IconRightZoom = 0D;
            this.btnperbaruimenu.IconVisible = true;
            this.btnperbaruimenu.IconZoom = 90D;
            this.btnperbaruimenu.IsTab = false;
            this.btnperbaruimenu.Location = new System.Drawing.Point(145, 0);
            this.btnperbaruimenu.Name = "btnperbaruimenu";
            this.btnperbaruimenu.Normalcolor = System.Drawing.Color.DarkCyan;
            this.btnperbaruimenu.OnHovercolor = System.Drawing.Color.Cyan;
            this.btnperbaruimenu.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnperbaruimenu.selected = false;
            this.btnperbaruimenu.Size = new System.Drawing.Size(148, 44);
            this.btnperbaruimenu.TabIndex = 13;
            this.btnperbaruimenu.Text = "Perbarui";
            this.btnperbaruimenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnperbaruimenu.Textcolor = System.Drawing.Color.Black;
            this.btnperbaruimenu.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnperbaruimenu.Click += new System.EventHandler(this.btnperbaruimenu_Click);
            // 
            // btntambahmenu
            // 
            this.btntambahmenu.Active = false;
            this.btntambahmenu.Activecolor = System.Drawing.Color.DarkCyan;
            this.btntambahmenu.BackColor = System.Drawing.Color.DarkCyan;
            this.btntambahmenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btntambahmenu.BorderRadius = 0;
            this.btntambahmenu.ButtonText = "Tambah";
            this.btntambahmenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btntambahmenu.DisabledColor = System.Drawing.Color.Gray;
            this.btntambahmenu.Iconcolor = System.Drawing.Color.Transparent;
            this.btntambahmenu.Iconimage = ((System.Drawing.Image)(resources.GetObject("btntambahmenu.Iconimage")));
            this.btntambahmenu.Iconimage_right = null;
            this.btntambahmenu.Iconimage_right_Selected = null;
            this.btntambahmenu.Iconimage_Selected = null;
            this.btntambahmenu.IconMarginLeft = 0;
            this.btntambahmenu.IconMarginRight = 0;
            this.btntambahmenu.IconRightVisible = true;
            this.btntambahmenu.IconRightZoom = 0D;
            this.btntambahmenu.IconVisible = true;
            this.btntambahmenu.IconZoom = 90D;
            this.btntambahmenu.IsTab = false;
            this.btntambahmenu.Location = new System.Drawing.Point(0, 0);
            this.btntambahmenu.Name = "btntambahmenu";
            this.btntambahmenu.Normalcolor = System.Drawing.Color.DarkCyan;
            this.btntambahmenu.OnHovercolor = System.Drawing.Color.Cyan;
            this.btntambahmenu.OnHoverTextColor = System.Drawing.Color.Black;
            this.btntambahmenu.selected = false;
            this.btntambahmenu.Size = new System.Drawing.Size(148, 44);
            this.btntambahmenu.TabIndex = 11;
            this.btntambahmenu.Text = "Tambah";
            this.btntambahmenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btntambahmenu.Textcolor = System.Drawing.Color.Black;
            this.btntambahmenu.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntambahmenu.Click += new System.EventHandler(this.btntambahmenu_Click);
            // 
            // Tambahmenu
            // 
            this.Tambahmenu.BackColor = System.Drawing.Color.Cyan;
            this.Tambahmenu.Controls.Add(this.label7);
            this.Tambahmenu.Controls.Add(this.bunifuCustomTextbox4);
            this.Tambahmenu.Controls.Add(this.pictureBox1);
            this.Tambahmenu.Controls.Add(this.bunifuCustomTextbox2);
            this.Tambahmenu.Controls.Add(this.label1);
            this.Tambahmenu.Controls.Add(this.label2);
            this.Tambahmenu.Controls.Add(this.pictureBox2);
            this.Tambahmenu.Controls.Add(this.pictureBox4);
            this.Tambahmenu.Controls.Add(this.bunifuCustomTextbox3);
            this.Tambahmenu.Controls.Add(this.label3);
            this.Tambahmenu.Controls.Add(this.label4);
            this.Tambahmenu.Controls.Add(this.label5);
            this.Tambahmenu.Controls.Add(this.label6);
            this.Tambahmenu.Controls.Add(this.bunifuCustomDataGrid1);
            this.Tambahmenu.Controls.Add(this.btntambhbatal);
            this.Tambahmenu.Controls.Add(this.btntambah);
            this.Tambahmenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tambahmenu.Location = new System.Drawing.Point(0, 47);
            this.Tambahmenu.Name = "Tambahmenu";
            this.Tambahmenu.Size = new System.Drawing.Size(586, 374);
            this.Tambahmenu.TabIndex = 56;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(189, 158);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 13);
            this.label7.TabIndex = 84;
            this.label7.Text = "Rp.";
            // 
            // bunifuCustomTextbox4
            // 
            this.bunifuCustomTextbox4.BackColor = System.Drawing.Color.Cyan;
            this.bunifuCustomTextbox4.BorderColor = System.Drawing.Color.SeaGreen;
            this.bunifuCustomTextbox4.Location = new System.Drawing.Point(190, 85);
            this.bunifuCustomTextbox4.MaxLength = 10;
            this.bunifuCustomTextbox4.Name = "bunifuCustomTextbox4";
            this.bunifuCustomTextbox4.Size = new System.Drawing.Size(155, 20);
            this.bunifuCustomTextbox4.TabIndex = 82;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::bismillah_jadi.Properties.Resources.icons8_check_for_payment_96;
            this.pictureBox1.Location = new System.Drawing.Point(31, 155);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(18, 18);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 80;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuCustomTextbox2
            // 
            this.bunifuCustomTextbox2.BackColor = System.Drawing.Color.Cyan;
            this.bunifuCustomTextbox2.BorderColor = System.Drawing.Color.SeaGreen;
            this.bunifuCustomTextbox2.Location = new System.Drawing.Point(219, 155);
            this.bunifuCustomTextbox2.MaxLength = 10000000;
            this.bunifuCustomTextbox2.Name = "bunifuCustomTextbox2";
            this.bunifuCustomTextbox2.Size = new System.Drawing.Size(125, 20);
            this.bunifuCustomTextbox2.TabIndex = 79;
            this.bunifuCustomTextbox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.bunifuCustomTextbox2_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(171, 155);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(12, 18);
            this.label1.TabIndex = 78;
            this.label1.Text = ":";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(55, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 18);
            this.label2.TabIndex = 77;
            this.label2.Text = "Biaya Pendaftaran";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::bismillah_jadi.Properties.Resources.icons8_name_96;
            this.pictureBox2.Location = new System.Drawing.Point(31, 120);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(18, 18);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 76;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::bismillah_jadi.Properties.Resources.icons8_name_tag_woman_horizontal_96;
            this.pictureBox4.Location = new System.Drawing.Point(31, 85);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(18, 18);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 75;
            this.pictureBox4.TabStop = false;
            // 
            // bunifuCustomTextbox3
            // 
            this.bunifuCustomTextbox3.BackColor = System.Drawing.Color.Cyan;
            this.bunifuCustomTextbox3.BorderColor = System.Drawing.Color.SeaGreen;
            this.bunifuCustomTextbox3.Location = new System.Drawing.Point(189, 120);
            this.bunifuCustomTextbox3.MaxLength = 50;
            this.bunifuCustomTextbox3.Name = "bunifuCustomTextbox3";
            this.bunifuCustomTextbox3.Size = new System.Drawing.Size(155, 20);
            this.bunifuCustomTextbox3.TabIndex = 73;
            this.bunifuCustomTextbox3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.bunifuCustomTextbox3_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(171, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(12, 18);
            this.label3.TabIndex = 72;
            this.label3.Text = ":";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(171, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(12, 18);
            this.label4.TabIndex = 71;
            this.label4.Text = ":";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(55, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 18);
            this.label5.TabIndex = 70;
            this.label5.Text = "Nama Golongan";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(55, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 18);
            this.label6.TabIndex = 69;
            this.label6.Text = "ID Golongan";
            // 
            // bunifuCustomDataGrid1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuCustomDataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.bunifuCustomDataGrid1.AutoGenerateColumns = false;
            this.bunifuCustomDataGrid1.BackgroundColor = System.Drawing.Color.LightCyan;
            this.bunifuCustomDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuCustomDataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuCustomDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.bunifuCustomDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bunifuCustomDataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idgolonganmemberDataGridViewTextBoxColumn,
            this.namagolonganmemberDataGridViewTextBoxColumn,
            this.biayapendaftaranDataGridViewTextBoxColumn});
            this.bunifuCustomDataGrid1.DataSource = this.golonganMemberBindingSource;
            this.bunifuCustomDataGrid1.DoubleBuffered = true;
            this.bunifuCustomDataGrid1.EnableHeadersVisualStyles = false;
            this.bunifuCustomDataGrid1.GridColor = System.Drawing.Color.DarkSlateGray;
            this.bunifuCustomDataGrid1.HeaderBgColor = System.Drawing.Color.LightSeaGreen;
            this.bunifuCustomDataGrid1.HeaderForeColor = System.Drawing.Color.Black;
            this.bunifuCustomDataGrid1.Location = new System.Drawing.Point(361, 85);
            this.bunifuCustomDataGrid1.Name = "bunifuCustomDataGrid1";
            this.bunifuCustomDataGrid1.ReadOnly = true;
            this.bunifuCustomDataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.bunifuCustomDataGrid1.Size = new System.Drawing.Size(213, 148);
            this.bunifuCustomDataGrid1.TabIndex = 33;
            // 
            // idgolonganmemberDataGridViewTextBoxColumn
            // 
            this.idgolonganmemberDataGridViewTextBoxColumn.DataPropertyName = "id_golongan_member";
            this.idgolonganmemberDataGridViewTextBoxColumn.HeaderText = "ID Golongan";
            this.idgolonganmemberDataGridViewTextBoxColumn.Name = "idgolonganmemberDataGridViewTextBoxColumn";
            this.idgolonganmemberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // namagolonganmemberDataGridViewTextBoxColumn
            // 
            this.namagolonganmemberDataGridViewTextBoxColumn.DataPropertyName = "nama_golongan_member";
            this.namagolonganmemberDataGridViewTextBoxColumn.HeaderText = "Nama Golongan";
            this.namagolonganmemberDataGridViewTextBoxColumn.Name = "namagolonganmemberDataGridViewTextBoxColumn";
            this.namagolonganmemberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // biayapendaftaranDataGridViewTextBoxColumn
            // 
            this.biayapendaftaranDataGridViewTextBoxColumn.DataPropertyName = "biaya_pendaftaran";
            this.biayapendaftaranDataGridViewTextBoxColumn.HeaderText = "Biaya Pendaftaran";
            this.biayapendaftaranDataGridViewTextBoxColumn.Name = "biayapendaftaranDataGridViewTextBoxColumn";
            this.biayapendaftaranDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // golonganMemberBindingSource
            // 
            this.golonganMemberBindingSource.DataMember = "Golongan Member";
            this.golonganMemberBindingSource.DataSource = this.koDingDataSet22;
            // 
            // koDingDataSet22
            // 
            this.koDingDataSet22.DataSetName = "KoDingDataSet22";
            this.koDingDataSet22.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btntambhbatal
            // 
            this.btntambhbatal.ActiveBorderThickness = 1;
            this.btntambhbatal.ActiveCornerRadius = 20;
            this.btntambhbatal.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btntambhbatal.ActiveForecolor = System.Drawing.Color.White;
            this.btntambhbatal.ActiveLineColor = System.Drawing.Color.Black;
            this.btntambhbatal.BackColor = System.Drawing.Color.Cyan;
            this.btntambhbatal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btntambhbatal.BackgroundImage")));
            this.btntambhbatal.ButtonText = "Batal";
            this.btntambhbatal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btntambhbatal.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntambhbatal.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btntambhbatal.IdleBorderThickness = 1;
            this.btntambhbatal.IdleCornerRadius = 20;
            this.btntambhbatal.IdleFillColor = System.Drawing.Color.White;
            this.btntambhbatal.IdleForecolor = System.Drawing.Color.Black;
            this.btntambhbatal.IdleLineColor = System.Drawing.Color.Black;
            this.btntambhbatal.Location = new System.Drawing.Point(268, 185);
            this.btntambhbatal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btntambhbatal.Name = "btntambhbatal";
            this.btntambhbatal.Size = new System.Drawing.Size(77, 34);
            this.btntambhbatal.TabIndex = 31;
            this.btntambhbatal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btntambhbatal.Click += new System.EventHandler(this.btntambhbatal_Click);
            // 
            // btntambah
            // 
            this.btntambah.ActiveBorderThickness = 1;
            this.btntambah.ActiveCornerRadius = 20;
            this.btntambah.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btntambah.ActiveForecolor = System.Drawing.Color.White;
            this.btntambah.ActiveLineColor = System.Drawing.Color.Black;
            this.btntambah.BackColor = System.Drawing.Color.Cyan;
            this.btntambah.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btntambah.BackgroundImage")));
            this.btntambah.ButtonText = "Tambah";
            this.btntambah.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btntambah.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntambah.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btntambah.IdleBorderThickness = 1;
            this.btntambah.IdleCornerRadius = 20;
            this.btntambah.IdleFillColor = System.Drawing.Color.White;
            this.btntambah.IdleForecolor = System.Drawing.Color.Black;
            this.btntambah.IdleLineColor = System.Drawing.Color.Black;
            this.btntambah.Location = new System.Drawing.Point(185, 185);
            this.btntambah.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btntambah.Name = "btntambah";
            this.btntambah.Size = new System.Drawing.Size(77, 34);
            this.btntambah.TabIndex = 30;
            this.btntambah.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btntambah.Click += new System.EventHandler(this.btntambah_Click);
            // 
            // golongan_MemberTableAdapter
            // 
            this.golongan_MemberTableAdapter.ClearBeforeFill = true;
            // 
            // Perbaruimenu
            // 
            this.Perbaruimenu.BackColor = System.Drawing.Color.Cyan;
            this.Perbaruimenu.Controls.Add(this.label8);
            this.Perbaruimenu.Controls.Add(this.pictureBox3);
            this.Perbaruimenu.Controls.Add(this.bunifuCustomTextbox1);
            this.Perbaruimenu.Controls.Add(this.label25);
            this.Perbaruimenu.Controls.Add(this.label26);
            this.Perbaruimenu.Controls.Add(this.bunifuCustomDataGrid3);
            this.Perbaruimenu.Controls.Add(this.btnprbruibatal);
            this.Perbaruimenu.Controls.Add(this.btnperbarui);
            this.Perbaruimenu.Controls.Add(this.pictureBox5);
            this.Perbaruimenu.Controls.Add(this.pictureBox6);
            this.Perbaruimenu.Controls.Add(this.txtperbaruiid);
            this.Perbaruimenu.Controls.Add(this.txtperbaruinama);
            this.Perbaruimenu.Controls.Add(this.label27);
            this.Perbaruimenu.Controls.Add(this.label28);
            this.Perbaruimenu.Controls.Add(this.label29);
            this.Perbaruimenu.Controls.Add(this.label30);
            this.Perbaruimenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Perbaruimenu.Location = new System.Drawing.Point(0, 47);
            this.Perbaruimenu.Name = "Perbaruimenu";
            this.Perbaruimenu.Size = new System.Drawing.Size(586, 374);
            this.Perbaruimenu.TabIndex = 84;
            this.Perbaruimenu.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(187, 158);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 13);
            this.label8.TabIndex = 84;
            this.label8.Text = "Rp.";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::bismillah_jadi.Properties.Resources.icons8_check_for_payment_96;
            this.pictureBox3.Location = new System.Drawing.Point(31, 155);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(18, 18);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 37;
            this.pictureBox3.TabStop = false;
            // 
            // bunifuCustomTextbox1
            // 
            this.bunifuCustomTextbox1.BackColor = System.Drawing.Color.Cyan;
            this.bunifuCustomTextbox1.BorderColor = System.Drawing.Color.SeaGreen;
            this.bunifuCustomTextbox1.Location = new System.Drawing.Point(212, 155);
            this.bunifuCustomTextbox1.MaxLength = 1000000;
            this.bunifuCustomTextbox1.Name = "bunifuCustomTextbox1";
            this.bunifuCustomTextbox1.Size = new System.Drawing.Size(132, 20);
            this.bunifuCustomTextbox1.TabIndex = 36;
            this.bunifuCustomTextbox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.bunifuCustomTextbox2_KeyPress);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(171, 155);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(12, 18);
            this.label25.TabIndex = 35;
            this.label25.Text = ":";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(55, 155);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(120, 18);
            this.label26.TabIndex = 34;
            this.label26.Text = "Biaya Pendaftaran";
            // 
            // bunifuCustomDataGrid3
            // 
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuCustomDataGrid3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.bunifuCustomDataGrid3.AutoGenerateColumns = false;
            this.bunifuCustomDataGrid3.BackgroundColor = System.Drawing.Color.LightCyan;
            this.bunifuCustomDataGrid3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuCustomDataGrid3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuCustomDataGrid3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.bunifuCustomDataGrid3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bunifuCustomDataGrid3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idgolonganmemberDataGridViewTextBoxColumn1,
            this.namagolonganmemberDataGridViewTextBoxColumn1,
            this.biayapendaftaranDataGridViewTextBoxColumn1});
            this.bunifuCustomDataGrid3.DataSource = this.golonganMemberBindingSource;
            this.bunifuCustomDataGrid3.DoubleBuffered = true;
            this.bunifuCustomDataGrid3.EnableHeadersVisualStyles = false;
            this.bunifuCustomDataGrid3.GridColor = System.Drawing.Color.DarkSlateGray;
            this.bunifuCustomDataGrid3.HeaderBgColor = System.Drawing.Color.LightSeaGreen;
            this.bunifuCustomDataGrid3.HeaderForeColor = System.Drawing.Color.Black;
            this.bunifuCustomDataGrid3.Location = new System.Drawing.Point(361, 85);
            this.bunifuCustomDataGrid3.Name = "bunifuCustomDataGrid3";
            this.bunifuCustomDataGrid3.ReadOnly = true;
            this.bunifuCustomDataGrid3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.bunifuCustomDataGrid3.Size = new System.Drawing.Size(213, 148);
            this.bunifuCustomDataGrid3.TabIndex = 33;
            // 
            // idgolonganmemberDataGridViewTextBoxColumn1
            // 
            this.idgolonganmemberDataGridViewTextBoxColumn1.DataPropertyName = "id_golongan_member";
            this.idgolonganmemberDataGridViewTextBoxColumn1.HeaderText = "ID Golongan";
            this.idgolonganmemberDataGridViewTextBoxColumn1.Name = "idgolonganmemberDataGridViewTextBoxColumn1";
            this.idgolonganmemberDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // namagolonganmemberDataGridViewTextBoxColumn1
            // 
            this.namagolonganmemberDataGridViewTextBoxColumn1.DataPropertyName = "nama_golongan_member";
            this.namagolonganmemberDataGridViewTextBoxColumn1.HeaderText = "Nama Golongan";
            this.namagolonganmemberDataGridViewTextBoxColumn1.Name = "namagolonganmemberDataGridViewTextBoxColumn1";
            this.namagolonganmemberDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // biayapendaftaranDataGridViewTextBoxColumn1
            // 
            this.biayapendaftaranDataGridViewTextBoxColumn1.DataPropertyName = "biaya_pendaftaran";
            this.biayapendaftaranDataGridViewTextBoxColumn1.HeaderText = "Biaya Pendaftaran";
            this.biayapendaftaranDataGridViewTextBoxColumn1.Name = "biayapendaftaranDataGridViewTextBoxColumn1";
            this.biayapendaftaranDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // btnprbruibatal
            // 
            this.btnprbruibatal.ActiveBorderThickness = 1;
            this.btnprbruibatal.ActiveCornerRadius = 20;
            this.btnprbruibatal.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnprbruibatal.ActiveForecolor = System.Drawing.Color.White;
            this.btnprbruibatal.ActiveLineColor = System.Drawing.Color.Black;
            this.btnprbruibatal.BackColor = System.Drawing.Color.Cyan;
            this.btnprbruibatal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnprbruibatal.BackgroundImage")));
            this.btnprbruibatal.ButtonText = "Hapus";
            this.btnprbruibatal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnprbruibatal.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprbruibatal.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnprbruibatal.IdleBorderThickness = 1;
            this.btnprbruibatal.IdleCornerRadius = 20;
            this.btnprbruibatal.IdleFillColor = System.Drawing.Color.White;
            this.btnprbruibatal.IdleForecolor = System.Drawing.Color.Black;
            this.btnprbruibatal.IdleLineColor = System.Drawing.Color.Black;
            this.btnprbruibatal.Location = new System.Drawing.Point(268, 185);
            this.btnprbruibatal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnprbruibatal.Name = "btnprbruibatal";
            this.btnprbruibatal.Size = new System.Drawing.Size(77, 34);
            this.btnprbruibatal.TabIndex = 31;
            this.btnprbruibatal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnprbruibatal.Click += new System.EventHandler(this.btnprbruibatal_Click);
            // 
            // btnperbarui
            // 
            this.btnperbarui.ActiveBorderThickness = 1;
            this.btnperbarui.ActiveCornerRadius = 20;
            this.btnperbarui.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnperbarui.ActiveForecolor = System.Drawing.Color.White;
            this.btnperbarui.ActiveLineColor = System.Drawing.Color.Black;
            this.btnperbarui.BackColor = System.Drawing.Color.Cyan;
            this.btnperbarui.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnperbarui.BackgroundImage")));
            this.btnperbarui.ButtonText = "Perbarui";
            this.btnperbarui.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnperbarui.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnperbarui.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnperbarui.IdleBorderThickness = 1;
            this.btnperbarui.IdleCornerRadius = 20;
            this.btnperbarui.IdleFillColor = System.Drawing.Color.White;
            this.btnperbarui.IdleForecolor = System.Drawing.Color.Black;
            this.btnperbarui.IdleLineColor = System.Drawing.Color.Black;
            this.btnperbarui.Location = new System.Drawing.Point(185, 185);
            this.btnperbarui.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnperbarui.Name = "btnperbarui";
            this.btnperbarui.Size = new System.Drawing.Size(77, 34);
            this.btnperbarui.TabIndex = 30;
            this.btnperbarui.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnperbarui.Click += new System.EventHandler(this.btnperbarui_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::bismillah_jadi.Properties.Resources.icons8_name_96;
            this.pictureBox5.Location = new System.Drawing.Point(31, 120);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(18, 18);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 29;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::bismillah_jadi.Properties.Resources.icons8_name_tag_woman_horizontal_96;
            this.pictureBox6.Location = new System.Drawing.Point(31, 85);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(18, 18);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 24;
            this.pictureBox6.TabStop = false;
            // 
            // txtperbaruiid
            // 
            this.txtperbaruiid.BackColor = System.Drawing.Color.Cyan;
            this.txtperbaruiid.DataSource = this.golonganMemberBindingSource;
            this.txtperbaruiid.DisplayMember = "id_golongan_member";
            this.txtperbaruiid.FormattingEnabled = true;
            this.txtperbaruiid.Location = new System.Drawing.Point(189, 85);
            this.txtperbaruiid.MaxLength = 10;
            this.txtperbaruiid.Name = "txtperbaruiid";
            this.txtperbaruiid.Size = new System.Drawing.Size(155, 21);
            this.txtperbaruiid.TabIndex = 20;
            this.txtperbaruiid.ValueMember = "id_golongan_member";
            this.txtperbaruiid.SelectedIndexChanged += new System.EventHandler(this.txtperbaruiid_SelectedIndexChanged);
            // 
            // txtperbaruinama
            // 
            this.txtperbaruinama.BackColor = System.Drawing.Color.Cyan;
            this.txtperbaruinama.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtperbaruinama.Location = new System.Drawing.Point(189, 120);
            this.txtperbaruinama.MaxLength = 50;
            this.txtperbaruinama.Name = "txtperbaruinama";
            this.txtperbaruinama.Size = new System.Drawing.Size(155, 20);
            this.txtperbaruinama.TabIndex = 14;
            this.txtperbaruinama.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.bunifuCustomTextbox3_KeyPress);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(171, 85);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(12, 18);
            this.label27.TabIndex = 13;
            this.label27.Text = ":";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(171, 120);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(12, 18);
            this.label28.TabIndex = 12;
            this.label28.Text = ":";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(55, 120);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(100, 18);
            this.label29.TabIndex = 1;
            this.label29.Text = "Nama Golongan";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(55, 85);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(83, 18);
            this.label30.TabIndex = 0;
            this.label30.Text = "ID Golongan";
            // 
            // CRUD_Golongan_Member
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.Controls.Add(this.Perbaruimenu);
            this.Controls.Add(this.Tambahmenu);
            this.Controls.Add(this.panel1);
            this.Name = "CRUD_Golongan_Member";
            this.Size = new System.Drawing.Size(586, 421);
            this.Load += new System.EventHandler(this.CRUD_Golongan_Member_Load);
            this.panel1.ResumeLayout(false);
            this.Tambahmenu.ResumeLayout(false);
            this.Tambahmenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.golonganMemberBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.koDingDataSet22)).EndInit();
            this.Perbaruimenu.ResumeLayout(false);
            this.Perbaruimenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuFlatButton btnperbaruimenu;
        private Bunifu.Framework.UI.BunifuFlatButton btntambahmenu;
        private System.Windows.Forms.Panel Tambahmenu;
        private System.Windows.Forms.Label label7;
        private Bunifu.Framework.BunifuCustomTextbox bunifuCustomTextbox4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.BunifuCustomTextbox bunifuCustomTextbox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private Bunifu.Framework.BunifuCustomTextbox bunifuCustomTextbox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private Bunifu.Framework.UI.BunifuCustomDataGrid bunifuCustomDataGrid1;
        private Bunifu.Framework.UI.BunifuThinButton2 btntambhbatal;
        private Bunifu.Framework.UI.BunifuThinButton2 btntambah;
        private System.Windows.Forms.DataGridViewTextBoxColumn idgolonganmemberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn namagolonganmemberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn biayapendaftaranDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource golonganMemberBindingSource;
        private KoDingDataSet22 koDingDataSet22;
        private KoDingDataSet22TableAdapters.Golongan_MemberTableAdapter golongan_MemberTableAdapter;
        private System.Windows.Forms.Panel Perbaruimenu;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox3;
        private Bunifu.Framework.BunifuCustomTextbox bunifuCustomTextbox1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private Bunifu.Framework.UI.BunifuCustomDataGrid bunifuCustomDataGrid3;
        private System.Windows.Forms.DataGridViewTextBoxColumn idgolonganmemberDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn namagolonganmemberDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn biayapendaftaranDataGridViewTextBoxColumn1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnprbruibatal;
        private Bunifu.Framework.UI.BunifuThinButton2 btnperbarui;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.ComboBox txtperbaruiid;
        private Bunifu.Framework.BunifuCustomTextbox txtperbaruinama;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
    }
}
