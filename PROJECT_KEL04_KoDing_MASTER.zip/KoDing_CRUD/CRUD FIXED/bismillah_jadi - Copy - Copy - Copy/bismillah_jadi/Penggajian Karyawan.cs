﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace bismillah_jadi
{
    public partial class Penggajian_Karyawan : UserControl
    {
        public Penggajian_Karyawan()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                if (cek1(textBox1.Text) == false)
                {
                    clear();
                }
            }
        }

        private void clear()
        {
            nama.Text = "-";
            gaji.Text = "-";
            lembur.Text = "-";
            gaji_akhir.Text = "-";
            date.Text = "-";
            slip.Text = "-";
        }

        private Boolean cek(string id)
        {


            id = id.ToUpper();
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            SqlCommand dbcmd = connection.CreateCommand();


            string bulan = DateTime.Today.Month.ToString();
            string tahun = DateTime.Today.Year.ToString();

            string sql = "select id_pegawai,SUM(jam_lembur) from  [dbo].[Jam Lembur] where YEAR(tanggal_lembur) ='" + tahun + "' AND MONTH(tanggal_lembur)='" + bulan + "' AND id_pegawai='" + textBox1.Text + "' GROUP BY id_pegawai";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();

            while (reader.Read())
            {
                if ((reader.GetString(0).ToString().ToUpper() == id))
                {

                    lembur.Text = reader.GetValue(1).ToString();
                    double akhir = double.Parse(gaji.Text) + (double.Parse(lembur.Text) * 100000);
                    gaji_akhir.Text = Convert.ToString(akhir);
                    date.Text = DateTime.Now.ToString();
                    slip.Text = "slip";
                    return true;
                }
                else
                {
                    MessageBox.Show("Data Penggajian Bulan ini dengan ID Karyawan " + textBox1.Text + " Tidak Ditemukan");
                }
            }
            connection.Close();
            return false;
        }

        private Boolean cek1(string id)
        {


            id = id.ToUpper();
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            SqlCommand dbcmd = connection.CreateCommand();


            string bulan = DateTime.Today.Month.ToString();
            string tahun = DateTime.Today.Year.ToString();

            string sql = "select p.id_pegawai,p.nama_pegawai,g.gaji_pokok,g.id_golongan from [dbo].[Golongan Gaji] g, [dbo].[Pegawai] p where g.id_golongan = p.id_golongan AND p.id_pegawai='" + textBox1.Text + "'";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();

            while (reader.Read())
            {
                if ((reader.GetString(0).ToString().ToUpper() == id))
                {
                    nama.Text = reader.GetValue(1).ToString();
                    gaji.Text = reader.GetValue(2).ToString();
                    if (cek(textBox1.Text) == false)
                    {
                        gaji_akhir.Text = gaji.Text;
                    }
                    date.Text = DateTime.Now.ToString();
                    string a = textBox1.Text;
                    slip.Text = "SLP" + tahun + bulan + a.Substring(3, 3);
                    return true;
                }
                else
                {
                    MessageBox.Show("Data Penggajian Bulan ini dengan ID Karyawan " + textBox1.Text + " Tidak Ditemukan");
                }
            }
            connection.Close();
            return false;
        }



        private void Penggajian_Karyawan_Load(object sender, EventArgs e)
        {
            textBox1.Text = "KRY-";
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();


            try
            {
                if (textBox1.Text == "" || nama.Text == "" || gaji.Text == "" || lembur.Text == "" || gaji.Text == "" || date.Text == "" || slip.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {


                    DataTable dtData = new DataTable();
                    SqlCommand insert = new SqlCommand("sp_InsertTransaksiPenggajian", connection);
                    insert.CommandType = CommandType.StoredProcedure;
                    insert.Parameters.AddWithValue("@no_slip_gaji", slip.Text);
                    insert.Parameters.AddWithValue("@gaji_akhir", gaji_akhir.Text);
                    insert.Parameters.AddWithValue("@tanggal_penggajian", date.Text);
                    insert.Parameters.AddWithValue("@id_pegawai", textBox1.Text);
                    insert.Parameters.AddWithValue("@jam_lembur", lembur.Text);
                    int numRes = insert.ExecuteNonQuery();
                    if (numRes > 0)
                    {

                        MessageBox.Show("Penggajian Karyawan Berhasil Dilakukan!");
                        clear();



                    }
                    else
                        MessageBox.Show("Gagal Menyimpan! Coba Lagi!");
                }


            }

            catch
            {
                MessageBox.Show("Karyawan dengan ID " + textBox1.Text + " Telah Digaji", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

