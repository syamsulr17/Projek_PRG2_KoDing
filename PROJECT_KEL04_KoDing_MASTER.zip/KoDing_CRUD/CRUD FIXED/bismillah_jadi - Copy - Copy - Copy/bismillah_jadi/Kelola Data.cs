﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bismillah_jadi
{
    public partial class Kelola_Data : UserControl
    {
        public Kelola_Data()
        {
            InitializeComponent();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {

        }

        CRUD_Golongan_Member CRUD_Golongan_Member = new CRUD_Golongan_Member();
        private void btnmember_Click(object sender, EventArgs e)
        {
            CRUD_Golongan_Member.Visible = false;
            cruD_Member1.Visible = true;
            cruD_Daftar_Menu1.Visible = false;
            crudBahan1.Visible = false;
            cruD_Supplier1.Visible = false;
            
            panel1.Visible = false;

            
        }

        private void btncrudmenu_Click(object sender, EventArgs e)
        {
            CRUD_Golongan_Member.Visible = false;
            cruD_Daftar_Menu1.Visible = true;
            cruD_Member1.Visible = false;
            crudBahan1.Visible = false;
            cruD_Supplier1.Visible = false;
            panel1.Visible = false;


        }

        private void btncrudsupplier_Click(object sender, EventArgs e)
        {
            CRUD_Golongan_Member.Visible = false;
            cruD_Daftar_Menu1.Visible = false;
            cruD_Member1.Visible = false;
            crudBahan1.Visible = false;
            cruD_Supplier1.Visible = true;
            panel1.Visible = false;
            
        }

        private void btncrudbahan_Click(object sender, EventArgs e)
        {
            CRUD_Golongan_Member.Visible = false;
            cruD_Daftar_Menu1.Visible = false;
            cruD_Member1.Visible = false;
            crudBahan1.Visible = true;
            cruD_Supplier1.Visible = false;
            panel1.Visible = false;
            
        }

        private void Kelola_Data_Load(object sender, EventArgs e)
        {
            
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {
            CRUD_Golongan_Member.Visible = false;
            cruD_Daftar_Menu1.Visible = false;
            cruD_Member1.Visible = false;
            crudBahan1.Visible = false;
            cruD_Supplier1.Visible = false;
            panel1.Visible = true;
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            CRUD_Golongan_Member.Visible = true;
            cruD_Daftar_Menu1.Visible = false;
            cruD_Member1.Visible = false;
            crudBahan1.Visible = false;
            cruD_Supplier1.Visible = false;
            panel1.Visible = false;
        }

        private void btncrudsupplier_Click_1(object sender, EventArgs e)
        {

        }

        

        private void bunifuFlatButton1_Click_1(object sender, EventArgs e)
        {
            
            CRUD_Golongan_Member.Visible = false;
            cruD_Daftar_Menu1.Visible = false;
            cruD_Member1.Visible = false;
            crudBahan1.Visible = false;
            cruD_Supplier1.Visible = false;
            panel1.Visible = false;
        }
    }
}
