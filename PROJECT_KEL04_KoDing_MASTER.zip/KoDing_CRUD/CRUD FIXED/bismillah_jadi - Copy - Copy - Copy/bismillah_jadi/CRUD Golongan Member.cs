﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace bismillah_jadi
{
    public partial class CRUD_Golongan_Member : UserControl
    {
        public CRUD_Golongan_Member()
        {
            InitializeComponent();
        }

        private void bunifuCustomTextbox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsLetter(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void bunifuCustomTextbox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsDigit(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btntambah_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            try
            {
                if (bunifuCustomTextbox4.Text == "" || bunifuCustomTextbox3.Text == "" || bunifuCustomTextbox2.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    SqlCommand insert = new SqlCommand("sp_InsertGolonganMember", connection);
                    insert.CommandType = CommandType.StoredProcedure;
                    insert.Parameters.AddWithValue("@id_golongan_member", bunifuCustomTextbox4.Text);
                    insert.Parameters.AddWithValue("@nama_golongan_member", bunifuCustomTextbox3.Text);
                    insert.Parameters.AddWithValue("@biaya_pendaftaran", bunifuCustomTextbox2.Text);
                    int numRes = insert.ExecuteNonQuery();
                    if (numRes > 0)
                    {
                        MessageBox.Show("Data Golongan Gaji Berhasil Disimpan!");
                        clear();
                        Refreshdata();

                        string query = "select id_golongan_member from [dbo].[Golongan Member] order by id_golongan_member desc";
                        bunifuCustomTextbox4.Text = autoNumber("GLM-", query);
                    }
                    else
                        MessageBox.Show("Gagal Menyimpan! Coba Lagi!");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private string autoNumber(string firstText, string query)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            string result = "";
            int num = 0;
            try
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;

        }

        private void clear()
        {
            bunifuCustomTextbox3.Text = "";
            bunifuCustomTextbox2.Text = "";

        }

        private void Refreshdata()
        {
            this.golongan_MemberTableAdapter.Fill(this.koDingDataSet22.Golongan_Member);
        }

        private void CRUD_Golongan_Member_Load(object sender, EventArgs e)
        {
            string query = "select id_golongan_member from [dbo].[Golongan Member] order by id_golongan_member desc";
            bunifuCustomTextbox4.Text = autoNumber("GLM-", query);

            this.golongan_MemberTableAdapter.Fill(this.koDingDataSet22.Golongan_Member);
        }

        private void btntambhbatal_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void btnperbarui_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            try
            {
                if (txtperbaruiid.Text == "" || txtperbaruinama.Text == "" || bunifuCustomTextbox1.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    SqlCommand update = new SqlCommand("sp_UpdateGolonganMember", connection);
                    update.CommandType = CommandType.StoredProcedure;

                    update.Parameters.AddWithValue("@id_golongan_member", txtperbaruiid.Text);
                    update.Parameters.AddWithValue("@nama_golongan_member", txtperbaruinama.Text);
                    update.Parameters.AddWithValue("@biaya_pendaftaran", bunifuCustomTextbox1.Text);
                    update.ExecuteNonQuery();

                    MessageBox.Show("Berhasil Memperbaharui Data!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    clear1();
                    txtperbaruiid.Text = "---Pilih ID Golongan---";

                    Refreshdata();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void clear1()
        {
            txtperbaruiid.Text = "";
            txtperbaruinama.Text = "";
            bunifuCustomTextbox1.Text = "";

        }

        private void btnprbruibatal_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            try
            {
                if (txtperbaruiid.Text == "" || txtperbaruinama.Text == "" || bunifuCustomTextbox1.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string message = "Hapus Data??";
                    string title = "Confirmation";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result = MessageBox.Show(message, title, buttons);
                    if (result == DialogResult.Yes)
                    {

                        SqlCommand delete = new SqlCommand("sp_DeleteGolonganMember", connection);
                        delete.CommandType = CommandType.StoredProcedure;

                        delete.Parameters.AddWithValue("@id_golongan_member", txtperbaruiid.Text);
                        int numRes = delete.ExecuteNonQuery();
                        if (numRes >= 0)
                        {
                            MessageBox.Show("Data Golongan Berhasil Dihapus!", "Infomation!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            Refreshdata();
                            clear1();
                            txtperbaruiid.Text = "---Pilih ID Golongan---";

                        }
                        else
                            MessageBox.Show("Gagal Menghapus! Coba Lagi!");
                    }
                    else
                    {
                        clear1();
                        txtperbaruiid.Text = "---Pilih ID Golongan---";
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void btntambahmenu_Click(object sender, EventArgs e)
        {
            string query = "select id_golongan_member from [dbo].[Golongan Member] order by id_golongan_member desc";
            bunifuCustomTextbox4.Text = autoNumber("GLM-", query);

            Tambahmenu.Visible = true; ;
            Perbaruimenu.Visible = false;
        }

        private void btnperbaruimenu_Click(object sender, EventArgs e)
        {
            Perbaruimenu.Visible = true;
            Tambahmenu.Visible = false;
        }

        private void txtperbaruiid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            SqlCommand dbcmd = connection.CreateCommand();
            string sql = "select * from [dbo].[Golongan Member] where id_golongan_member='" + txtperbaruiid.Text + "'";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();
            reader.Read();
            txtperbaruinama.Text = reader.GetValue(1).ToString();
            bunifuCustomTextbox1.Text = reader.GetValue(2).ToString();
        }
    }
}
