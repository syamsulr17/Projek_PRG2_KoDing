﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace bismillah_jadi
{
    public partial class CRUD_Daftar_Menu : UserControl
    {

        public CRUD_Daftar_Menu()
        {
            InitializeComponent();
           
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            string query = "select id_golongan from [dbo].[Golongan Gaji] order by id_golongan desc";
            bunifuCustomTextbox4.Text = autoNumber("GOL-", query);

            Tambahmenu.Visible = true; ;
            Perbaruimenu.Visible = false;
           
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            Perbaruimenu.Visible = true;
            Tambahmenu.Visible = false;
            
            Perbaruimenu.Refresh();
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
           
            Tambahmenu.Visible = false;
            Perbaruimenu.Visible = false;
           
            Perbaruimenu.Refresh();
        }

        private void tambahmenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btntambah_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            try
            {
                if (bunifuCustomTextbox4.Text =="" || bunifuCustomTextbox3.Text==""|| bunifuCustomTextbox2.Text=="")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    SqlCommand insert = new SqlCommand("sp_InsertGolonganGaji", connection);
                    insert.CommandType = CommandType.StoredProcedure;
                    insert.Parameters.AddWithValue("@id_golongan", bunifuCustomTextbox4.Text);
                    insert.Parameters.AddWithValue("@nama_golongan", bunifuCustomTextbox3.Text);
                    insert.Parameters.AddWithValue("@gaji_pokok", bunifuCustomTextbox2.Text);
                    int numRes = insert.ExecuteNonQuery();
                    if (numRes > 0)
                    {
                        MessageBox.Show("Data Golongan Gaji Berhasil Disimpan!");
                        clear();
                        Refreshdata();

                        string query = "select id_golongan from [dbo].[Golongan Gaji] order by id_golongan desc";
                        bunifuCustomTextbox4.Text = autoNumber("GOL-", query);
                    }
                    else
                        MessageBox.Show("Gagal Menyimpan! Coba Lagi!");
                }
            
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private string autoNumber(string firstText, string query)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            string result = "";
            int num = 0;
            try
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void btnhapus_Click(object sender, EventArgs e)
        {

        }

        private void btnhapusbatal_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnhapusnamamenu_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtperbaruiid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtperbaruinama_TextChanged(object sender, EventArgs e)
        {

        }

        private void txthapusidmenu_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txthapusnamamenu_TextChanged(object sender, EventArgs e)
        {

        }

        private void txttambahid_TextChanged(object sender, EventArgs e)
        {
           

        }
       

        private void clear()
        {
            bunifuCustomTextbox3.Text = "";
            bunifuCustomTextbox2.Text = "";

        }

        private void clear1()
        {
            txtperbaruiid.Text = "";
            txtperbaruinama.Text = "";
            bunifuCustomTextbox1.Text = "";

        }
        private void txtperbaruiid_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            SqlCommand dbcmd = connection.CreateCommand();
            string sql = "select * from [dbo].[Golongan Gaji] where id_golongan='" + txtperbaruiid.Text + "'";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();
            reader.Read();
            txtperbaruinama.Text = reader.GetValue(1).ToString();  
            bunifuCustomTextbox1.Text = reader.GetValue(2).ToString();
        }

        private void btnperbarui_Click_1(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            try
            {
                if (txtperbaruiid.Text == "" || txtperbaruinama.Text == "" || bunifuCustomTextbox1.Text=="")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    SqlCommand update = new SqlCommand("sp_UpdateGolonganGaji", connection);
                    update.CommandType = CommandType.StoredProcedure;

                    update.Parameters.AddWithValue("@id_golongan", txtperbaruiid.Text);
                    update.Parameters.AddWithValue("@nama_golongan", txtperbaruinama.Text);
                    update.Parameters.AddWithValue("@gaji_pokok", bunifuCustomTextbox1.Text);
                    update.ExecuteNonQuery();

                    MessageBox.Show("Berhasil Memperbaharui Data!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    clear1();
                    txtperbaruiid.Text = "---Pilih ID Golongan---";
                    
                    Refreshdata();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }


       


        private void btnhapus_Click_1(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            try
            {
                if (txtperbaruiid.Text == "" || txtperbaruinama.Text == "" || bunifuCustomTextbox1.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string message = "Hapus Data??";
                    string title = "Confirmation";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result = MessageBox.Show(message, title, buttons);
                    if (result == DialogResult.Yes)
                    {

                        SqlCommand delete = new SqlCommand("sp_DeleteGolonganGaji", connection);
                        delete.CommandType = CommandType.StoredProcedure;

                        delete.Parameters.AddWithValue("@id_golongan", txtperbaruiid.Text);
                        int numRes = delete.ExecuteNonQuery();
                        if (numRes >= 0)
                        {
                            MessageBox.Show("Data Golongan Berhasil Dihapus!", "Infomation!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            Refreshdata();
                            clear1();
                            txtperbaruiid.Text = "---Pilih ID Golongan---";
                            
                        }
                        else
                            MessageBox.Show("Gagal Menghapus! Coba Lagi!");
                    }
                    else
                    {
                        clear1();
                        txtperbaruiid.Text = "---Pilih ID Golongan---";
                    }
                }

              
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }


        
       
       

        private void txttambahnama_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsLetter(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }


        private void CRUD_Daftar_Menu_Load(object sender, EventArgs e)
        {
            string query = "select id_golongan from [dbo].[Golongan Gaji] order by id_golongan desc";
            bunifuCustomTextbox4.Text = autoNumber("GOL-", query);

            this.golongan_GajiTableAdapter.Fill(this.koDingDataSet18.Golongan_Gaji);
            txtperbaruiid.Text = "---Pilih Menu---";
            
           
        }
        private void Refreshdata()
        {
            this.golongan_GajiTableAdapter.Fill(this.koDingDataSet18.Golongan_Gaji);
        }

        private void Perbaruimenu_Paint(object sender, PaintEventArgs e)
        {

        }


        private void bunifuCustomTextbox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsLetter(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void bunifuCustomTextbox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsDigit(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtperbaruinama_KeyPress_3(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsLetter(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void bunifuCustomTextbox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsDigit(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnprbruibatal_Click(object sender, EventArgs e)
        {

        }

        private void bunifuCustomDataGrid3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
