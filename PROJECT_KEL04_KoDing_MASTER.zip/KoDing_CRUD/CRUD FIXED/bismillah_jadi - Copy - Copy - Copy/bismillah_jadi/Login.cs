﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bismillah_jadi
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string a, b, c;
            a = label6.Text;
            b = a.Substring(0, 1);
            c = a.Substring(1, a.Length - 1);
            label6.Text = c + b;
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            if (isAuthentic(btnusername.Text, btnpass.Text))
            {
                GenericIdentity myid = new GenericIdentity(btnusername.Text);

                DataSet dsrole = new DataSet();
                dsrole = getRoles(btnusername.Text);
                string[] myrole = new string[dsrole.Tables[0].Rows.Count];

                for (int i = 0; i < dsrole.Tables[0].Rows.Count; i++)
                {
                    myrole[i] = dsrole.Tables[0].Rows[i][0].ToString();
                }

                GenericPrincipal mypricipal = new GenericPrincipal(myid, myrole);

                Thread.CurrentPrincipal = mypricipal;
                this.Hide();
                if (Thread.CurrentPrincipal.IsInRole("Karyawan"))
                {
                    Home home = new Home();
                    home.Show();
                }
                else
                {
                    Admin admin = new Admin();
                    admin.Show();
                }
            }
            else
            {
                MessageBox.Show("Username atau Password salah!");
            }

        }

        public bool isAuthentic(string uname, string pass)
        {
            bool autentik = false;

            try
            {
                string conn = "integrated security=true; data source = PUJIA\\SQLEXPRESS; initial catalog= KoDing";
                SqlConnection myConnection = new SqlConnection(conn);
                myConnection.Open();

                SqlCommand command = new SqlCommand("SELECT password FROM Pegawai WHERE id_pegawai='" + uname + "'", myConnection);

                var obj = command.ExecuteScalar();

                if (pass == obj.ToString())
                {
                    autentik = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            return autentik;
        }
        private DataSet getRoles(string uname)
        {
            DataSet ds = new DataSet();
            try
            {
                string conn = "integrated security=true; data source = PUJIA\\SQLEXPRESS; initial catalog= KoDing";
                SqlConnection myConnection = new SqlConnection(conn);
                myConnection.Open();

                SqlDataAdapter ad = new SqlDataAdapter("SELECT role FROM Pegawai WHERE id_pegawai='" + uname + "'", myConnection);
                ad.Fill(ds);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            return ds;
        }
        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void bunifuImageButton3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }


    }
}
