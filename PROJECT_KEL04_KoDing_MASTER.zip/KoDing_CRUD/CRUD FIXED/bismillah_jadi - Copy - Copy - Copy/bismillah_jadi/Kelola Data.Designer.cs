﻿namespace bismillah_jadi
{
    partial class Kelola_Data
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Kelola_Data));
            this.panel5 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.cruD_Daftar_Menu1 = new bismillah_jadi.CRUD_Daftar_Menu();
            this.cruD_Member1 = new bismillah_jadi.CRUD_Member();
            this.cruD_Supplier1 = new bismillah_jadi.CRUD_Supplier();
            this.crudBahan1 = new bismillah_jadi.CRUDBahan();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnmember = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btncrudsupplier = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btncrudbahan = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(586, 50);
            this.panel5.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(243, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(176, 33);
            this.label1.TabIndex = 10;
            this.label1.Text = "Kelola Data";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // cruD_Daftar_Menu1
            // 
            this.cruD_Daftar_Menu1.BackColor = System.Drawing.Color.DarkCyan;
            this.cruD_Daftar_Menu1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cruD_Daftar_Menu1.Location = new System.Drawing.Point(0, 50);
            this.cruD_Daftar_Menu1.Name = "cruD_Daftar_Menu1";
            this.cruD_Daftar_Menu1.Size = new System.Drawing.Size(586, 371);
            this.cruD_Daftar_Menu1.TabIndex = 5;
            this.cruD_Daftar_Menu1.Visible = false;
            // 
            // cruD_Member1
            // 
            this.cruD_Member1.BackColor = System.Drawing.Color.DarkCyan;
            this.cruD_Member1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cruD_Member1.Location = new System.Drawing.Point(0, 50);
            this.cruD_Member1.Name = "cruD_Member1";
            this.cruD_Member1.Size = new System.Drawing.Size(586, 371);
            this.cruD_Member1.TabIndex = 6;
            this.cruD_Member1.Visible = false;
            // 
            // cruD_Supplier1
            // 
            this.cruD_Supplier1.BackColor = System.Drawing.Color.DarkCyan;
            this.cruD_Supplier1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cruD_Supplier1.Location = new System.Drawing.Point(0, 50);
            this.cruD_Supplier1.Name = "cruD_Supplier1";
            this.cruD_Supplier1.Size = new System.Drawing.Size(586, 371);
            this.cruD_Supplier1.TabIndex = 7;
            this.cruD_Supplier1.Visible = false;
            // 
            // crudBahan1
            // 
            this.crudBahan1.BackColor = System.Drawing.Color.Cyan;
            this.crudBahan1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crudBahan1.Location = new System.Drawing.Point(0, 50);
            this.crudBahan1.Name = "crudBahan1";
            this.crudBahan1.Size = new System.Drawing.Size(586, 371);
            this.crudBahan1.TabIndex = 8;
            this.crudBahan1.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 50);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(586, 371);
            this.panel1.TabIndex = 9;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DarkCyan;
            this.panel7.Controls.Add(this.bunifuFlatButton2);
            this.panel7.Location = new System.Drawing.Point(247, 171);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(336, 49);
            this.panel7.TabIndex = 6;
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Active = false;
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.DarkSlateGray;
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.DarkCyan;
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 0;
            this.bunifuFlatButton2.ButtonText = "Kelola Menu";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton2.Iconimage")));
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 20;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 60D;
            this.bunifuFlatButton2.IsTab = false;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(0, 0);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.DarkCyan;
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.CadetBlue;
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(336, 49);
            this.bunifuFlatButton2.TabIndex = 3;
            this.bunifuFlatButton2.Text = "Kelola Menu";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton2.Click += new System.EventHandler(this.btncrudmenu_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkCyan;
            this.panel3.Controls.Add(this.btnmember);
            this.panel3.Location = new System.Drawing.Point(3, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(355, 49);
            this.panel3.TabIndex = 7;
            // 
            // btnmember
            // 
            this.btnmember.Active = false;
            this.btnmember.Activecolor = System.Drawing.Color.DarkSlateGray;
            this.btnmember.BackColor = System.Drawing.Color.DarkCyan;
            this.btnmember.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnmember.BorderRadius = 0;
            this.btnmember.ButtonText = "Kelola Member";
            this.btnmember.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmember.DisabledColor = System.Drawing.Color.Gray;
            this.btnmember.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnmember.Iconcolor = System.Drawing.Color.Transparent;
            this.btnmember.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnmember.Iconimage")));
            this.btnmember.Iconimage_right = null;
            this.btnmember.Iconimage_right_Selected = null;
            this.btnmember.Iconimage_Selected = null;
            this.btnmember.IconMarginLeft = 20;
            this.btnmember.IconMarginRight = 0;
            this.btnmember.IconRightVisible = true;
            this.btnmember.IconRightZoom = 0D;
            this.btnmember.IconVisible = true;
            this.btnmember.IconZoom = 60D;
            this.btnmember.IsTab = false;
            this.btnmember.Location = new System.Drawing.Point(0, 0);
            this.btnmember.Name = "btnmember";
            this.btnmember.Normalcolor = System.Drawing.Color.DarkCyan;
            this.btnmember.OnHovercolor = System.Drawing.Color.CadetBlue;
            this.btnmember.OnHoverTextColor = System.Drawing.Color.White;
            this.btnmember.selected = false;
            this.btnmember.Size = new System.Drawing.Size(355, 49);
            this.btnmember.TabIndex = 3;
            this.btnmember.Text = "Kelola Member";
            this.btnmember.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnmember.Textcolor = System.Drawing.Color.White;
            this.btnmember.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmember.Click += new System.EventHandler(this.btnmember_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkCyan;
            this.panel4.Controls.Add(this.btncrudsupplier);
            this.panel4.Location = new System.Drawing.Point(3, 61);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(355, 49);
            this.panel4.TabIndex = 6;
            // 
            // btncrudsupplier
            // 
            this.btncrudsupplier.Active = false;
            this.btncrudsupplier.Activecolor = System.Drawing.Color.DarkSlateGray;
            this.btncrudsupplier.BackColor = System.Drawing.Color.DarkCyan;
            this.btncrudsupplier.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncrudsupplier.BorderRadius = 0;
            this.btncrudsupplier.ButtonText = "Kelola Supplier";
            this.btncrudsupplier.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncrudsupplier.DisabledColor = System.Drawing.Color.Gray;
            this.btncrudsupplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btncrudsupplier.Iconcolor = System.Drawing.Color.Transparent;
            this.btncrudsupplier.Iconimage = ((System.Drawing.Image)(resources.GetObject("btncrudsupplier.Iconimage")));
            this.btncrudsupplier.Iconimage_right = null;
            this.btncrudsupplier.Iconimage_right_Selected = null;
            this.btncrudsupplier.Iconimage_Selected = null;
            this.btncrudsupplier.IconMarginLeft = 20;
            this.btncrudsupplier.IconMarginRight = 0;
            this.btncrudsupplier.IconRightVisible = true;
            this.btncrudsupplier.IconRightZoom = 0D;
            this.btncrudsupplier.IconVisible = true;
            this.btncrudsupplier.IconZoom = 60D;
            this.btncrudsupplier.IsTab = false;
            this.btncrudsupplier.Location = new System.Drawing.Point(0, 0);
            this.btncrudsupplier.Name = "btncrudsupplier";
            this.btncrudsupplier.Normalcolor = System.Drawing.Color.DarkCyan;
            this.btncrudsupplier.OnHovercolor = System.Drawing.Color.CadetBlue;
            this.btncrudsupplier.OnHoverTextColor = System.Drawing.Color.White;
            this.btncrudsupplier.selected = false;
            this.btncrudsupplier.Size = new System.Drawing.Size(355, 49);
            this.btncrudsupplier.TabIndex = 2;
            this.btncrudsupplier.Text = "Kelola Supplier";
            this.btncrudsupplier.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btncrudsupplier.Textcolor = System.Drawing.Color.White;
            this.btncrudsupplier.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncrudsupplier.Click += new System.EventHandler(this.btncrudsupplier_Click_1);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkCyan;
            this.panel6.Controls.Add(this.btncrudbahan);
            this.panel6.Location = new System.Drawing.Point(247, 226);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(336, 49);
            this.panel6.TabIndex = 5;
            // 
            // btncrudbahan
            // 
            this.btncrudbahan.Active = false;
            this.btncrudbahan.Activecolor = System.Drawing.Color.DarkSlateGray;
            this.btncrudbahan.BackColor = System.Drawing.Color.DarkCyan;
            this.btncrudbahan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncrudbahan.BorderRadius = 0;
            this.btncrudbahan.ButtonText = "Kelola Bahan";
            this.btncrudbahan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncrudbahan.DisabledColor = System.Drawing.Color.Gray;
            this.btncrudbahan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btncrudbahan.Iconcolor = System.Drawing.Color.Transparent;
            this.btncrudbahan.Iconimage = ((System.Drawing.Image)(resources.GetObject("btncrudbahan.Iconimage")));
            this.btncrudbahan.Iconimage_right = null;
            this.btncrudbahan.Iconimage_right_Selected = null;
            this.btncrudbahan.Iconimage_Selected = null;
            this.btncrudbahan.IconMarginLeft = 20;
            this.btncrudbahan.IconMarginRight = 0;
            this.btncrudbahan.IconRightVisible = true;
            this.btncrudbahan.IconRightZoom = 0D;
            this.btncrudbahan.IconVisible = true;
            this.btncrudbahan.IconZoom = 60D;
            this.btncrudbahan.IsTab = false;
            this.btncrudbahan.Location = new System.Drawing.Point(0, 0);
            this.btncrudbahan.Name = "btncrudbahan";
            this.btncrudbahan.Normalcolor = System.Drawing.Color.DarkCyan;
            this.btncrudbahan.OnHovercolor = System.Drawing.Color.CadetBlue;
            this.btncrudbahan.OnHoverTextColor = System.Drawing.Color.White;
            this.btncrudbahan.selected = false;
            this.btncrudbahan.Size = new System.Drawing.Size(336, 49);
            this.btncrudbahan.TabIndex = 3;
            this.btncrudbahan.Text = "Kelola Bahan";
            this.btncrudbahan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btncrudbahan.Textcolor = System.Drawing.Color.White;
            this.btncrudbahan.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncrudbahan.Click += new System.EventHandler(this.btncrudbahan_Click);
            // 
            // bunifuFlatButton3
            // 
            this.bunifuFlatButton3.Active = false;
            this.bunifuFlatButton3.Activecolor = System.Drawing.Color.DarkSlateGray;
            this.bunifuFlatButton3.BackColor = System.Drawing.Color.DarkCyan;
            this.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton3.BorderRadius = 0;
            this.bunifuFlatButton3.ButtonText = "Kelola Golongan Member";
            this.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton3.Iconimage")));
            this.bunifuFlatButton3.Iconimage_right = null;
            this.bunifuFlatButton3.Iconimage_right_Selected = null;
            this.bunifuFlatButton3.Iconimage_Selected = null;
            this.bunifuFlatButton3.IconMarginLeft = 20;
            this.bunifuFlatButton3.IconMarginRight = 0;
            this.bunifuFlatButton3.IconRightVisible = true;
            this.bunifuFlatButton3.IconRightZoom = 0D;
            this.bunifuFlatButton3.IconVisible = true;
            this.bunifuFlatButton3.IconZoom = 60D;
            this.bunifuFlatButton3.IsTab = false;
            this.bunifuFlatButton3.Location = new System.Drawing.Point(0, 0);
            this.bunifuFlatButton3.Name = "bunifuFlatButton3";
            this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.DarkCyan;
            this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.CadetBlue;
            this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton3.selected = false;
            this.bunifuFlatButton3.Size = new System.Drawing.Size(358, 49);
            this.bunifuFlatButton3.TabIndex = 4;
            this.bunifuFlatButton3.Text = "Kelola Golongan Member";
            this.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton3.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton3.Click += new System.EventHandler(this.bunifuFlatButton3_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.bunifuFlatButton3);
            this.panel8.Location = new System.Drawing.Point(3, 116);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(358, 49);
            this.panel8.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkCyan;
            this.panel2.Controls.Add(this.bunifuFlatButton1);
            this.panel2.Location = new System.Drawing.Point(247, 281);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(336, 49);
            this.panel2.TabIndex = 11;
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Active = false;
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.DarkSlateGray;
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.DarkCyan;
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Kelola Inventaris";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 20;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 60D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(0, 0);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.DarkCyan;
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.CadetBlue;
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(336, 49);
            this.bunifuFlatButton1.TabIndex = 3;
            this.bunifuFlatButton1.Text = "Kelola Inventaris";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click_1);
            // 
            // Kelola_Data
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.crudBahan1);
            this.Controls.Add(this.cruD_Supplier1);
            this.Controls.Add(this.cruD_Member1);
            this.Controls.Add(this.cruD_Daftar_Menu1);
            this.Controls.Add(this.panel5);
            this.Name = "Kelola_Data";
            this.Size = new System.Drawing.Size(586, 421);
            this.Load += new System.EventHandler(this.Kelola_Data_Load);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel5;
        private CRUD_Daftar_Menu cruD_Daftar_Menu1;
        private CRUD_Member cruD_Member1;
        private CRUD_Supplier cruD_Supplier1;
        private CRUDBahan crudBahan1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel6;
        private Bunifu.Framework.UI.BunifuFlatButton btncrudbahan;
        private System.Windows.Forms.Panel panel4;
        private Bunifu.Framework.UI.BunifuFlatButton btncrudsupplier;
        private System.Windows.Forms.Panel panel3;
        private Bunifu.Framework.UI.BunifuFlatButton btnmember;
        private System.Windows.Forms.Panel panel7;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private System.Windows.Forms.Panel panel8;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton3;
    }
}
