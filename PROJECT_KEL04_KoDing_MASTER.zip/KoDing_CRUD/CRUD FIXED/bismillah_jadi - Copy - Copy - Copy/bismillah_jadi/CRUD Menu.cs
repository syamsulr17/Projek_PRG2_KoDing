﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace bismillah_jadi
{
    public partial class CRUD_Menu : UserControl
    {
        public CRUD_Menu()
        {
            InitializeComponent();
        }

        private void txttbhid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsLetter(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txttbhnama_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsDigit(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btntambah_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();


            try
            {
                if (txttbhid.Text == "" || txttbhnama.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {


                    DataTable dtData = new DataTable();
                    SqlCommand insert = new SqlCommand("sp_InsertDaftarMenu", connection);
                    insert.CommandType = CommandType.StoredProcedure;
                    insert.Parameters.AddWithValue("@nama_menu", txttbhid.Text);
                    insert.Parameters.AddWithValue("@harga_menu", txttbhnama.Text);
                    int numRes = insert.ExecuteNonQuery();
                    if (numRes > 0)
                    {
                        MessageBox.Show("Data Daftar Menu Berhasil Disimpan!");
                        clear();
                        Refreshdata();

                    }
                    else
                        MessageBox.Show("Gagal Menyimpan! Coba Lagi!");
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void clear()
        {
            txttbhid.Clear();
            txttbhnama.Clear();
            txtupdateid.Text= "---Pilih Menu---";
            txtupdatenama.Clear();
        }

        private void Refreshdata()
        {
            this.daftar_MenuTableAdapter.Fill(this.koDingDataSet25.Daftar_Menu);
        }

        

        private void CRUD_Menu_Load(object sender, EventArgs e)
        {
            this.daftar_MenuTableAdapter.Fill(this.koDingDataSet25.Daftar_Menu);
        }

        private void btnbatal_Click(object sender, EventArgs e)
        {

            clear();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();



            try
            {
                if (txtupdateid.Text == "" || txtupdatenama.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {


                    SqlCommand update = new SqlCommand("sp_UpdateDaftarMenu", connection);
                    update.CommandType = CommandType.StoredProcedure;

                    update.Parameters.AddWithValue("@nama_menu", txtupdateid.Text);
                    update.Parameters.AddWithValue("@harga_menu", txtupdatenama.Text);
                    update.ExecuteNonQuery();
                    MessageBox.Show("Berhasil Memperbaharui Data!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Refreshdata();
                    txtupdateid.Text = "---Pilih Menu---";
                    clear();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Pembaruan Gagal!" + ex.Message.ToString());
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            try
            {
                if (txtupdateid.Text == "" || txtupdatenama.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string message = "Hapus Data??";
                    string title = "Confirmation";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result = MessageBox.Show(message, title, buttons);
                    if (result == DialogResult.Yes)
                    {

                        SqlCommand delete = new SqlCommand("sp_DeleteDaftarMenu", connection);
                        delete.CommandType = CommandType.StoredProcedure;

                        delete.Parameters.AddWithValue("@nama_menu", txtupdateid.Text);
                        int numRes = delete.ExecuteNonQuery();
                        if (numRes >= 0)
                        {
                            MessageBox.Show("Daftar Menu Berhasil Dihapus!", "Infomation!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            Refreshdata();
                            txtupdateid.Text = "---Pilih Menu---";
                            clear();
                        }
                        else
                            MessageBox.Show("Gagal Menghapus! Coba Lagi!");
                    }
                    else
                    {
                        txtupdateid.Text = "---Pilih Menu---";
                        txtupdatenama.Clear();
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void txtupdateid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            SqlCommand dbcmd = connection.CreateCommand();
            string sql = "select * from [dbo].[Daftar Menu] where nama_menu='" + txtupdateid.Text + "'";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();
            reader.Read();
            txtupdatenama.Text = reader.GetValue(1).ToString();
        }

        private void btntambahbahan_Click(object sender, EventArgs e)
        {

            perbaruibahan.Visible = false;
            tambahbahan.Visible = true;

        }

        private void btnperbaruibahan_Click(object sender, EventArgs e)
        {
            perbaruibahan.Visible = true ;
            tambahbahan.Visible = false;
        }
    }
}
