﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace bismillah_jadi
{
    public partial class Home : Form
    {
        

        public Home()
        {
            InitializeComponent();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void bunifuImageButton2_Click(object sender, EventArgs e)
        {
            if(this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            { 
                if (this.WindowState == FormWindowState.Maximized)
                {
                    this.WindowState = FormWindowState.Normal;
                }
                else
                {
                    this.WindowState = FormWindowState.Minimized;
                }
            }

       
        }

        private void bunifuImageButton3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label2.Text = Thread.CurrentPrincipal.Identity.Name;


        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            //about.Visible = true;
            //container.Visible = false;
            //penjualan_Kopi1.Visible = false;
            //bunifuThinButton24.Visible = false;
            //cruD_Daftar_Menu1.Visible = false;
            //daftar_Member1.Visible = false;
            //pembelian_bahan1.Visible = false;
            //penjualan_Kopi1.Visible = false;
            //about.Visible = true ;
            //container.Visible = false;
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            //container.Visible = true;
            //bunifuThinButton24.Visible = false;
            //cruD_Daftar_Menu1.Visible = false;
            //daftar_Member1.Visible = false;
            //pembelian_bahan1.Visible = false;
            //penjualan_Kopi1.Visible = false;
            //about.Visible = false;

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            
            
           
           
            
        }

        private void bunifuFlatButton1_Click_1(object sender, EventArgs e)
        {
            //penjualan_Kopi1.Visible = true;
            //container.Visible = false;
            //about.Visible = false;
            //bunifuThinButton24.Visible = true;
            //cruD_Daftar_Menu1.Visible = false;
            //daftar_Member1.Visible = false;
            //pembelian_bahan1.Visible = false;
            //penjualan_Kopi1.Visible = true ;
            //about.Visible = false;
            //container.Visible = false;
        }

        private void bunifuThinButton24_Click(object sender, EventArgs e)
        {
            

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            //cruD_Daftar_Menu1.Visible = false;
            //daftar_Member1.Visible = false;
            //pembelian_bahan1.Visible = true;
            //penjualan_Kopi1.Visible = false;
            //about.Visible = false;
            //container.Visible = false;
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            //cruD_Daftar_Menu1.Visible = false;
            daftar_Member1.Visible = true;
            kelola_Data1.Visible = false;
            //pembelian_bahan1.Visible = false;
            //penjualan_Kopi1.Visible = false;
            //about.Visible = false;
            //container.Visible = false;

        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            //cruD_Daftar_Menu1.Visible = true;
            //daftar_Member1.Visible = false;
            //pembelian_bahan1.Visible = false;
            //penjualan_Kopi1.Visible = false;
            //about.Visible = false;
            //container.Visible = false;
            //crudBahan1.Visible = true;
            kelola_Data1.Visible = true;
            daftar_Member1.Visible = false;
            cruD_Inventaris1.Visible = false;

        }

        private void header_Paint(object sender, PaintEventArgs e)
        {

        }

        private void kelola_Data1_Load(object sender, EventArgs e)
        {

        }
        

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
        }

        private void penjualan_Kopi1_Load(object sender, EventArgs e)
        {
            

        }

        private void crudBahan2_Load(object sender, EventArgs e)
        {



        }

        private void crudBahan1_Load(object sender, EventArgs e)
        {





        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {

        }
    }
}
