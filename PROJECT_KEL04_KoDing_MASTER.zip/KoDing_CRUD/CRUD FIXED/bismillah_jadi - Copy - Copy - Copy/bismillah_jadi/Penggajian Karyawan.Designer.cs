﻿namespace bismillah_jadi
{
    partial class Penggajian_Karyawan
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Penggajian_Karyawan));
            this.panel3 = new System.Windows.Forms.Panel();
            this.nama = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lembur = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.slip = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.date = new System.Windows.Forms.Label();
            this.gaji = new System.Windows.Forms.Label();
            this.gaji_akhir = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.btnperbarui = new Bunifu.Framework.UI.BunifuThinButton2();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Cyan;
            this.panel3.Controls.Add(this.nama);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.lembur);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.slip);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Controls.Add(this.date);
            this.panel3.Controls.Add(this.gaji);
            this.panel3.Controls.Add(this.gaji_akhir);
            this.panel3.Controls.Add(this.label31);
            this.panel3.Controls.Add(this.label30);
            this.panel3.Controls.Add(this.label29);
            this.panel3.Controls.Add(this.label28);
            this.panel3.Controls.Add(this.label27);
            this.panel3.Controls.Add(this.label26);
            this.panel3.Controls.Add(this.label24);
            this.panel3.Controls.Add(this.label23);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Location = new System.Drawing.Point(53, 44);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(480, 303);
            this.panel3.TabIndex = 34;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // nama
            // 
            this.nama.AutoSize = true;
            this.nama.Location = new System.Drawing.Point(277, 71);
            this.nama.Name = "nama";
            this.nama.Size = new System.Drawing.Size(10, 13);
            this.nama.TabIndex = 92;
            this.nama.Text = "-";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(89, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 18);
            this.label6.TabIndex = 91;
            this.label6.Text = "Nama Pegawai";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(277, 177);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 13);
            this.label5.TabIndex = 90;
            this.label5.Text = "Rp.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(277, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 13);
            this.label4.TabIndex = 89;
            this.label4.Text = "Rp.";
            // 
            // lembur
            // 
            this.lembur.AutoSize = true;
            this.lembur.Location = new System.Drawing.Point(277, 140);
            this.lembur.Name = "lembur";
            this.lembur.Size = new System.Drawing.Size(10, 13);
            this.lembur.TabIndex = 88;
            this.lembur.Text = "-";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(87, 140);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 18);
            this.label1.TabIndex = 87;
            this.label1.Text = "Jam Lembur";
            // 
            // slip
            // 
            this.slip.AutoSize = true;
            this.slip.Location = new System.Drawing.Point(277, 246);
            this.slip.Name = "slip";
            this.slip.Size = new System.Drawing.Size(10, 13);
            this.slip.TabIndex = 86;
            this.slip.Text = "-";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(243, 246);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(10, 13);
            this.label2.TabIndex = 85;
            this.label2.Text = ":";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(87, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 18);
            this.label3.TabIndex = 84;
            this.label3.Text = "No Slip Gaji";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Cyan;
            this.textBox1.Location = new System.Drawing.Point(280, 38);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(113, 20);
            this.textBox1.TabIndex = 83;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // date
            // 
            this.date.AutoSize = true;
            this.date.Location = new System.Drawing.Point(277, 212);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(10, 13);
            this.date.TabIndex = 82;
            this.date.Text = "-";
            // 
            // gaji
            // 
            this.gaji.AutoSize = true;
            this.gaji.Location = new System.Drawing.Point(313, 104);
            this.gaji.Name = "gaji";
            this.gaji.Size = new System.Drawing.Size(10, 13);
            this.gaji.TabIndex = 81;
            this.gaji.Text = "-";
            // 
            // gaji_akhir
            // 
            this.gaji_akhir.AutoSize = true;
            this.gaji_akhir.Location = new System.Drawing.Point(313, 177);
            this.gaji_akhir.Name = "gaji_akhir";
            this.gaji_akhir.Size = new System.Drawing.Size(10, 13);
            this.gaji_akhir.TabIndex = 80;
            this.gaji_akhir.Text = "-";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(243, 212);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(10, 13);
            this.label31.TabIndex = 79;
            this.label31.Text = ":";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(243, 177);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(10, 13);
            this.label30.TabIndex = 78;
            this.label30.Text = ":";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(243, 140);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(10, 13);
            this.label29.TabIndex = 77;
            this.label29.Text = ":";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(243, 104);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(10, 13);
            this.label28.TabIndex = 76;
            this.label28.Text = ":";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(243, 38);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(10, 13);
            this.label27.TabIndex = 75;
            this.label27.Text = ":";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(87, 104);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(72, 18);
            this.label26.TabIndex = 74;
            this.label26.Text = "Gaji Pokok";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(87, 177);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(70, 18);
            this.label24.TabIndex = 73;
            this.label24.Text = "Gaji Akhir";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(87, 212);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(105, 18);
            this.label23.TabIndex = 72;
            this.label23.Text = "Date Penggajian";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(87, 38);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(77, 18);
            this.label22.TabIndex = 71;
            this.label22.Text = "ID Pegawai";
            // 
            // btnperbarui
            // 
            this.btnperbarui.ActiveBorderThickness = 1;
            this.btnperbarui.ActiveCornerRadius = 20;
            this.btnperbarui.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnperbarui.ActiveForecolor = System.Drawing.Color.White;
            this.btnperbarui.ActiveLineColor = System.Drawing.Color.Black;
            this.btnperbarui.BackColor = System.Drawing.Color.Cyan;
            this.btnperbarui.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnperbarui.BackgroundImage")));
            this.btnperbarui.ButtonText = "Gaji";
            this.btnperbarui.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnperbarui.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnperbarui.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnperbarui.IdleBorderThickness = 1;
            this.btnperbarui.IdleCornerRadius = 20;
            this.btnperbarui.IdleFillColor = System.Drawing.Color.White;
            this.btnperbarui.IdleForecolor = System.Drawing.Color.Black;
            this.btnperbarui.IdleLineColor = System.Drawing.Color.Black;
            this.btnperbarui.Location = new System.Drawing.Point(369, 354);
            this.btnperbarui.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnperbarui.Name = "btnperbarui";
            this.btnperbarui.Size = new System.Drawing.Size(77, 34);
            this.btnperbarui.TabIndex = 65;
            this.btnperbarui.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnperbarui.Click += new System.EventHandler(this.bunifuThinButton21_Click);
            // 
            // Penggajian_Karyawan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.btnperbarui);
            this.Name = "Penggajian_Karyawan";
            this.Size = new System.Drawing.Size(586, 421);
            this.Load += new System.EventHandler(this.Penggajian_Karyawan_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label nama;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lembur;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label slip;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label date;
        private System.Windows.Forms.Label gaji;
        private System.Windows.Forms.Label gaji_akhir;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private Bunifu.Framework.UI.BunifuThinButton2 btnperbarui;
    }
}
