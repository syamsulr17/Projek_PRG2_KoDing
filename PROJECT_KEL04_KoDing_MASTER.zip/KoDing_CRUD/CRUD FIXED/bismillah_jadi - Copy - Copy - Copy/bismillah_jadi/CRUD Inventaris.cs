﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace bismillah_jadi
{
    public partial class CRUD_Inventaris : UserControl
    {
        public CRUD_Inventaris()
        {
            InitializeComponent();
        }

        private void txttbhnama_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsLetter(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void bunifuCustomTextbox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsDigit(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btntambah_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();


            try
            {
                if (txttbhid.Text == "" || txttbhnama.Text == "" || bunifuCustomTextbox1.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    SqlCommand insert = new SqlCommand("sp_InsertInventarisBarang", connection);
                    insert.CommandType = CommandType.StoredProcedure;

                    insert.Parameters.AddWithValue("@id_inventaris", txttbhid.Text);
                    insert.Parameters.AddWithValue("@nama_barang", txttbhnama.Text);
                    insert.Parameters.AddWithValue("@jumlah_barang", bunifuCustomTextbox1.Text);
                    int numRes = insert.ExecuteNonQuery();
                    if (numRes > 0)
                    {
                        MessageBox.Show("Data Inventaris Berhasil Disimpan!");
                        clear();
                        Refreshdata();

                        string query = "select id_inventaris from [dbo].[Inventaris Barang] order by id_inventaris desc";
                        txttbhid.Text = autoNumber("INV-", query);
                    }
                    else
                        MessageBox.Show("Gagal Menyimpan! Coba Lagi!");
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
        private void Refreshdata()
        {
            this.inventaris_BarangTableAdapter.Fill(this.koDingDataSet24.Inventaris_Barang);
        }
        private string autoNumber(string firstText, string query)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            string result = "";
            int num = 0;
            try
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;

        }
        private void clear()
        {
            txttbhnama.Clear();
            txtupdatenama.Clear();
            bunifuCustomTextbox1.Clear();
            bunifuCustomTextbox2.Clear();
        }

        private void btnbatal_Click(object sender, EventArgs e)
        {
            string query = "select id_inventaris from [dbo].[Inventaris Barang] order by id_inventaris desc";
            txttbhid.Text = autoNumber("INV-", query);
            clear();
        }

        private void CRUD_Inventaris_Load(object sender, EventArgs e)
        {
            string query = "select id_inventaris from [dbo].[Inventaris Barang] order by id_inventaris desc";
            txttbhid.Text = autoNumber("INV-", query);

            this.inventaris_BarangTableAdapter.Fill(this.koDingDataSet24.Inventaris_Barang);

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();



            try
            {
                if (txtupdateid.Text == "" || txtupdatenama.Text == "" || bunifuCustomTextbox2.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {


                    SqlCommand update = new SqlCommand("sp_UpdateInventarisBarang", connection);
                    update.CommandType = CommandType.StoredProcedure;

                    update.Parameters.AddWithValue("@id_inventaris", txtupdateid.Text);
                    update.Parameters.AddWithValue("@nama_barang", txtupdatenama.Text);
                    update.Parameters.AddWithValue("@jumlah_barang", bunifuCustomTextbox2.Text);
                    update.ExecuteNonQuery();
                    MessageBox.Show("Berhasil Memperbaharui Data!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Refreshdata();
                    txtupdateid.Text = "---Pilih ID Barang---";
                    clear();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Pembaruan Gagal!" + ex.Message.ToString());
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            try
            {
                if (txtupdateid.Text == "" || txtupdatenama.Text == "" || bunifuCustomTextbox2.Text=="")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string message = "Hapus Data??";
                    string title = "Confirmation";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result = MessageBox.Show(message, title, buttons);
                    if (result == DialogResult.Yes)
                    {

                        SqlCommand delete = new SqlCommand("sp_DeleteInventarisBarang", connection);
                        delete.CommandType = CommandType.StoredProcedure;

                        delete.Parameters.AddWithValue("@id_inventaris", txtupdateid.Text);
                        int numRes = delete.ExecuteNonQuery();
                        if (numRes >= 0)
                        {
                            MessageBox.Show("Data Inventaris Berhasil Dihapus!", "Infomation!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            Refreshdata();
                            txtupdateid.Text = "---Pilih ID Barang---";
                            clear();
                        }
                        else
                            MessageBox.Show("Gagal Menghapus! Coba Lagi!");
                    }
                    else
                    {
                        txtupdateid.Text = "---Pilih ID Barang---";
                        clear();
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void txtupdateid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            SqlCommand dbcmd = connection.CreateCommand();
            string sql = "select * from [dbo].[Inventaris Barang] where id_inventaris='" + txtupdateid.Text + "'";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();
            reader.Read();
            txtupdatenama.Text = reader.GetValue(1).ToString();
            bunifuCustomTextbox2.Text = reader.GetValue(2).ToString();
        }

        private void btntambahbahan_Click(object sender, EventArgs e)
        {

            string query = "select id_inventaris from [dbo].[Inventaris Barang] order by id_inventaris desc";
            txttbhid.Text = autoNumber("INV-", query);

            perbaruibahan.Visible = false;
            tambahbahan.Visible = true;
        }

        private void btnperbaruibahan_Click(object sender, EventArgs e)
        {
            perbaruibahan.Visible = true;
            tambahbahan.Visible = false;
        }
    }
}
