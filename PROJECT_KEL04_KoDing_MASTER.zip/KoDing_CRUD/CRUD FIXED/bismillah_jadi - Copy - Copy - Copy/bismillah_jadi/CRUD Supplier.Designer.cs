﻿namespace bismillah_jadi
{
    partial class CRUD_Supplier
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CRUD_Supplier));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnperbaruibahan = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btntambahbahan = new Bunifu.Framework.UI.BunifuFlatButton();
            this.tambahsuplier = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.txtplushargabahan = new Bunifu.Framework.BunifuCustomTextbox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.txtid = new Bunifu.Framework.BunifuCustomTextbox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.txtpluxemail = new Bunifu.Framework.BunifuCustomTextbox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.txtplusalamat = new Bunifu.Framework.BunifuCustomTextbox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtplusidbahan = new System.Windows.Forms.ComboBox();
            this.bahanBakuBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.koDingDataSet20 = new bismillah_jadi.KoDingDataSet20();
            this.update = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.idsupplierDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.namasupplierDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.alamatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idbahanDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hargabahanDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.koDingDataSet19 = new bismillah_jadi.KoDingDataSet19();
            this.btnclear = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnadd = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtplusnama = new Bunifu.Framework.BunifuCustomTextbox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.perbaruisupplier = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.txtharga = new Bunifu.Framework.BunifuCustomTextbox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtidbahan = new Bunifu.Framework.BunifuCustomTextbox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtemail = new Bunifu.Framework.BunifuCustomTextbox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtaddress = new Bunifu.Framework.BunifuCustomTextbox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txteditid = new System.Windows.Forms.ComboBox();
            this.bunifuCustomDataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.idsupplierDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.namasupplierDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.alamatDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idbahanDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hargabahanDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnhapus = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnupdate = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtname = new Bunifu.Framework.BunifuCustomTextbox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.supplierTableAdapter = new bismillah_jadi.KoDingDataSet19TableAdapters.SupplierTableAdapter();
            this.bahan_BakuTableAdapter = new bismillah_jadi.KoDingDataSet20TableAdapters.Bahan_BakuTableAdapter();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.tambahsuplier.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bahanBakuBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.koDingDataSet20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.update)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.koDingDataSet19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.perbaruisupplier.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkCyan;
            this.panel1.Controls.Add(this.btnperbaruibahan);
            this.panel1.Controls.Add(this.btntambahbahan);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(586, 47);
            this.panel1.TabIndex = 16;
            // 
            // btnperbaruibahan
            // 
            this.btnperbaruibahan.Active = false;
            this.btnperbaruibahan.Activecolor = System.Drawing.Color.DarkCyan;
            this.btnperbaruibahan.BackColor = System.Drawing.Color.DarkCyan;
            this.btnperbaruibahan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnperbaruibahan.BorderRadius = 0;
            this.btnperbaruibahan.ButtonText = "Perbarui";
            this.btnperbaruibahan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnperbaruibahan.DisabledColor = System.Drawing.Color.Gray;
            this.btnperbaruibahan.Iconcolor = System.Drawing.Color.Transparent;
            this.btnperbaruibahan.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnperbaruibahan.Iconimage")));
            this.btnperbaruibahan.Iconimage_right = null;
            this.btnperbaruibahan.Iconimage_right_Selected = null;
            this.btnperbaruibahan.Iconimage_Selected = null;
            this.btnperbaruibahan.IconMarginLeft = 0;
            this.btnperbaruibahan.IconMarginRight = 0;
            this.btnperbaruibahan.IconRightVisible = true;
            this.btnperbaruibahan.IconRightZoom = 0D;
            this.btnperbaruibahan.IconVisible = true;
            this.btnperbaruibahan.IconZoom = 90D;
            this.btnperbaruibahan.IsTab = false;
            this.btnperbaruibahan.Location = new System.Drawing.Point(145, 0);
            this.btnperbaruibahan.Name = "btnperbaruibahan";
            this.btnperbaruibahan.Normalcolor = System.Drawing.Color.DarkCyan;
            this.btnperbaruibahan.OnHovercolor = System.Drawing.Color.Cyan;
            this.btnperbaruibahan.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnperbaruibahan.selected = false;
            this.btnperbaruibahan.Size = new System.Drawing.Size(148, 44);
            this.btnperbaruibahan.TabIndex = 13;
            this.btnperbaruibahan.Text = "Perbarui";
            this.btnperbaruibahan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnperbaruibahan.Textcolor = System.Drawing.Color.Black;
            this.btnperbaruibahan.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnperbaruibahan.Click += new System.EventHandler(this.btnperbaruibahan_Click);
            // 
            // btntambahbahan
            // 
            this.btntambahbahan.Active = false;
            this.btntambahbahan.Activecolor = System.Drawing.Color.DarkCyan;
            this.btntambahbahan.BackColor = System.Drawing.Color.DarkCyan;
            this.btntambahbahan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btntambahbahan.BorderRadius = 0;
            this.btntambahbahan.ButtonText = "Tambah";
            this.btntambahbahan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btntambahbahan.DisabledColor = System.Drawing.Color.Gray;
            this.btntambahbahan.Iconcolor = System.Drawing.Color.Transparent;
            this.btntambahbahan.Iconimage = ((System.Drawing.Image)(resources.GetObject("btntambahbahan.Iconimage")));
            this.btntambahbahan.Iconimage_right = null;
            this.btntambahbahan.Iconimage_right_Selected = null;
            this.btntambahbahan.Iconimage_Selected = null;
            this.btntambahbahan.IconMarginLeft = 0;
            this.btntambahbahan.IconMarginRight = 0;
            this.btntambahbahan.IconRightVisible = true;
            this.btntambahbahan.IconRightZoom = 0D;
            this.btntambahbahan.IconVisible = true;
            this.btntambahbahan.IconZoom = 90D;
            this.btntambahbahan.IsTab = false;
            this.btntambahbahan.Location = new System.Drawing.Point(0, 0);
            this.btntambahbahan.Name = "btntambahbahan";
            this.btntambahbahan.Normalcolor = System.Drawing.Color.DarkCyan;
            this.btntambahbahan.OnHovercolor = System.Drawing.Color.Cyan;
            this.btntambahbahan.OnHoverTextColor = System.Drawing.Color.Black;
            this.btntambahbahan.selected = false;
            this.btntambahbahan.Size = new System.Drawing.Size(148, 44);
            this.btntambahbahan.TabIndex = 11;
            this.btntambahbahan.Text = "Tambah";
            this.btntambahbahan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btntambahbahan.Textcolor = System.Drawing.Color.Black;
            this.btntambahbahan.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntambahbahan.Click += new System.EventHandler(this.btntambahbahan_Click);
            // 
            // tambahsuplier
            // 
            this.tambahsuplier.BackColor = System.Drawing.Color.Cyan;
            this.tambahsuplier.Controls.Add(this.label25);
            this.tambahsuplier.Controls.Add(this.pictureBox6);
            this.tambahsuplier.Controls.Add(this.txtplushargabahan);
            this.tambahsuplier.Controls.Add(this.label11);
            this.tambahsuplier.Controls.Add(this.label12);
            this.tambahsuplier.Controls.Add(this.pictureBox5);
            this.tambahsuplier.Controls.Add(this.txtid);
            this.tambahsuplier.Controls.Add(this.label9);
            this.tambahsuplier.Controls.Add(this.label10);
            this.tambahsuplier.Controls.Add(this.pictureBox4);
            this.tambahsuplier.Controls.Add(this.txtpluxemail);
            this.tambahsuplier.Controls.Add(this.label7);
            this.tambahsuplier.Controls.Add(this.label8);
            this.tambahsuplier.Controls.Add(this.pictureBox3);
            this.tambahsuplier.Controls.Add(this.txtplusalamat);
            this.tambahsuplier.Controls.Add(this.label5);
            this.tambahsuplier.Controls.Add(this.label6);
            this.tambahsuplier.Controls.Add(this.txtplusidbahan);
            this.tambahsuplier.Controls.Add(this.update);
            this.tambahsuplier.Controls.Add(this.btnclear);
            this.tambahsuplier.Controls.Add(this.btnadd);
            this.tambahsuplier.Controls.Add(this.pictureBox1);
            this.tambahsuplier.Controls.Add(this.pictureBox2);
            this.tambahsuplier.Controls.Add(this.txtplusnama);
            this.tambahsuplier.Controls.Add(this.label1);
            this.tambahsuplier.Controls.Add(this.label2);
            this.tambahsuplier.Controls.Add(this.label3);
            this.tambahsuplier.Controls.Add(this.label4);
            this.tambahsuplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tambahsuplier.Location = new System.Drawing.Point(0, 47);
            this.tambahsuplier.Name = "tambahsuplier";
            this.tambahsuplier.Size = new System.Drawing.Size(586, 374);
            this.tambahsuplier.TabIndex = 69;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(169, 246);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(24, 13);
            this.label25.TabIndex = 51;
            this.label25.Text = "Rp.";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::bismillah_jadi.Properties.Resources.icons8_check_for_payment_96;
            this.pictureBox6.Location = new System.Drawing.Point(11, 243);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(18, 18);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 50;
            this.pictureBox6.TabStop = false;
            // 
            // txtplushargabahan
            // 
            this.txtplushargabahan.BackColor = System.Drawing.Color.Cyan;
            this.txtplushargabahan.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtplushargabahan.Location = new System.Drawing.Point(198, 243);
            this.txtplushargabahan.MaxLength = 10;
            this.txtplushargabahan.Name = "txtplushargabahan";
            this.txtplushargabahan.Size = new System.Drawing.Size(126, 20);
            this.txtplushargabahan.TabIndex = 49;
            this.txtplushargabahan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtplushargabahan_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(151, 243);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(12, 18);
            this.label11.TabIndex = 48;
            this.label11.Text = ":";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(35, 243);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 18);
            this.label12.TabIndex = 47;
            this.label12.Text = "Harga Bahan";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::bismillah_jadi.Properties.Resources.icons8_check_for_payment_96;
            this.pictureBox5.Location = new System.Drawing.Point(11, 203);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(18, 18);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 46;
            this.pictureBox5.TabStop = false;
            // 
            // txtid
            // 
            this.txtid.BackColor = System.Drawing.Color.Cyan;
            this.txtid.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtid.Location = new System.Drawing.Point(169, 24);
            this.txtid.MaxLength = 10;
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(155, 20);
            this.txtid.TabIndex = 45;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(151, 203);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(12, 18);
            this.label9.TabIndex = 44;
            this.label9.Text = ":";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(35, 203);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 18);
            this.label10.TabIndex = 43;
            this.label10.Text = "ID Bahan";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::bismillah_jadi.Properties.Resources.icons8_check_for_payment_96;
            this.pictureBox4.Location = new System.Drawing.Point(11, 166);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(18, 18);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 42;
            this.pictureBox4.TabStop = false;
            // 
            // txtpluxemail
            // 
            this.txtpluxemail.BackColor = System.Drawing.Color.Cyan;
            this.txtpluxemail.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtpluxemail.Location = new System.Drawing.Point(169, 166);
            this.txtpluxemail.MaxLength = 50;
            this.txtpluxemail.Name = "txtpluxemail";
            this.txtpluxemail.Size = new System.Drawing.Size(155, 20);
            this.txtpluxemail.TabIndex = 41;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(151, 166);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(12, 18);
            this.label7.TabIndex = 40;
            this.label7.Text = ":";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(35, 166);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 18);
            this.label8.TabIndex = 39;
            this.label8.Text = "Email";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::bismillah_jadi.Properties.Resources.icons8_check_for_payment_96;
            this.pictureBox3.Location = new System.Drawing.Point(11, 95);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(18, 18);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 38;
            this.pictureBox3.TabStop = false;
            // 
            // txtplusalamat
            // 
            this.txtplusalamat.BackColor = System.Drawing.Color.Cyan;
            this.txtplusalamat.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtplusalamat.Location = new System.Drawing.Point(169, 95);
            this.txtplusalamat.MaxLength = 100;
            this.txtplusalamat.Multiline = true;
            this.txtplusalamat.Name = "txtplusalamat";
            this.txtplusalamat.Size = new System.Drawing.Size(155, 53);
            this.txtplusalamat.TabIndex = 37;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(151, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(12, 18);
            this.label5.TabIndex = 36;
            this.label5.Text = ":";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(35, 95);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 18);
            this.label6.TabIndex = 35;
            this.label6.Text = "Alamat";
            // 
            // txtplusidbahan
            // 
            this.txtplusidbahan.BackColor = System.Drawing.Color.Cyan;
            this.txtplusidbahan.DataSource = this.bahanBakuBindingSource;
            this.txtplusidbahan.DisplayMember = "id_bahan";
            this.txtplusidbahan.FormattingEnabled = true;
            this.txtplusidbahan.Location = new System.Drawing.Point(169, 203);
            this.txtplusidbahan.MaxLength = 10;
            this.txtplusidbahan.Name = "txtplusidbahan";
            this.txtplusidbahan.Size = new System.Drawing.Size(154, 21);
            this.txtplusidbahan.TabIndex = 34;
            this.txtplusidbahan.ValueMember = "id_bahan";
            // 
            // bahanBakuBindingSource
            // 
            this.bahanBakuBindingSource.DataMember = "Bahan Baku";
            this.bahanBakuBindingSource.DataSource = this.koDingDataSet20;
            // 
            // koDingDataSet20
            // 
            this.koDingDataSet20.DataSetName = "KoDingDataSet20";
            this.koDingDataSet20.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // update
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.update.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.update.AutoGenerateColumns = false;
            this.update.BackgroundColor = System.Drawing.Color.LightCyan;
            this.update.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.update.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.update.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.update.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.update.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idsupplierDataGridViewTextBoxColumn,
            this.namasupplierDataGridViewTextBoxColumn,
            this.alamatDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.idbahanDataGridViewTextBoxColumn,
            this.hargabahanDataGridViewTextBoxColumn});
            this.update.DataSource = this.supplierBindingSource;
            this.update.DoubleBuffered = true;
            this.update.EnableHeadersVisualStyles = false;
            this.update.GridColor = System.Drawing.Color.DarkSlateGray;
            this.update.HeaderBgColor = System.Drawing.Color.LightSeaGreen;
            this.update.HeaderForeColor = System.Drawing.Color.Black;
            this.update.Location = new System.Drawing.Point(341, 24);
            this.update.Name = "update";
            this.update.ReadOnly = true;
            this.update.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.update.Size = new System.Drawing.Size(235, 266);
            this.update.TabIndex = 33;
            // 
            // idsupplierDataGridViewTextBoxColumn
            // 
            this.idsupplierDataGridViewTextBoxColumn.DataPropertyName = "id_supplier";
            this.idsupplierDataGridViewTextBoxColumn.HeaderText = "ID Supplier";
            this.idsupplierDataGridViewTextBoxColumn.Name = "idsupplierDataGridViewTextBoxColumn";
            this.idsupplierDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // namasupplierDataGridViewTextBoxColumn
            // 
            this.namasupplierDataGridViewTextBoxColumn.DataPropertyName = "nama_supplier";
            this.namasupplierDataGridViewTextBoxColumn.HeaderText = "Nama Supplier";
            this.namasupplierDataGridViewTextBoxColumn.Name = "namasupplierDataGridViewTextBoxColumn";
            this.namasupplierDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // alamatDataGridViewTextBoxColumn
            // 
            this.alamatDataGridViewTextBoxColumn.DataPropertyName = "alamat";
            this.alamatDataGridViewTextBoxColumn.HeaderText = "Alamat";
            this.alamatDataGridViewTextBoxColumn.Name = "alamatDataGridViewTextBoxColumn";
            this.alamatDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // idbahanDataGridViewTextBoxColumn
            // 
            this.idbahanDataGridViewTextBoxColumn.DataPropertyName = "id_bahan";
            this.idbahanDataGridViewTextBoxColumn.HeaderText = "ID Bahan";
            this.idbahanDataGridViewTextBoxColumn.Name = "idbahanDataGridViewTextBoxColumn";
            this.idbahanDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // hargabahanDataGridViewTextBoxColumn
            // 
            this.hargabahanDataGridViewTextBoxColumn.DataPropertyName = "harga_bahan";
            this.hargabahanDataGridViewTextBoxColumn.HeaderText = "Harga Bahan";
            this.hargabahanDataGridViewTextBoxColumn.Name = "hargabahanDataGridViewTextBoxColumn";
            this.hargabahanDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // supplierBindingSource
            // 
            this.supplierBindingSource.DataMember = "Supplier";
            this.supplierBindingSource.DataSource = this.koDingDataSet19;
            // 
            // koDingDataSet19
            // 
            this.koDingDataSet19.DataSetName = "KoDingDataSet19";
            this.koDingDataSet19.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnclear
            // 
            this.btnclear.ActiveBorderThickness = 1;
            this.btnclear.ActiveCornerRadius = 20;
            this.btnclear.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnclear.ActiveForecolor = System.Drawing.Color.White;
            this.btnclear.ActiveLineColor = System.Drawing.Color.Black;
            this.btnclear.BackColor = System.Drawing.Color.Cyan;
            this.btnclear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnclear.BackgroundImage")));
            this.btnclear.ButtonText = "Batal";
            this.btnclear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnclear.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnclear.IdleBorderThickness = 1;
            this.btnclear.IdleCornerRadius = 20;
            this.btnclear.IdleFillColor = System.Drawing.Color.White;
            this.btnclear.IdleForecolor = System.Drawing.Color.Black;
            this.btnclear.IdleLineColor = System.Drawing.Color.Black;
            this.btnclear.Location = new System.Drawing.Point(247, 294);
            this.btnclear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(77, 34);
            this.btnclear.TabIndex = 31;
            this.btnclear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btnadd
            // 
            this.btnadd.ActiveBorderThickness = 1;
            this.btnadd.ActiveCornerRadius = 20;
            this.btnadd.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnadd.ActiveForecolor = System.Drawing.Color.White;
            this.btnadd.ActiveLineColor = System.Drawing.Color.Black;
            this.btnadd.BackColor = System.Drawing.Color.Cyan;
            this.btnadd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnadd.BackgroundImage")));
            this.btnadd.ButtonText = "Tambah";
            this.btnadd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnadd.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnadd.IdleBorderThickness = 1;
            this.btnadd.IdleCornerRadius = 20;
            this.btnadd.IdleFillColor = System.Drawing.Color.White;
            this.btnadd.IdleForecolor = System.Drawing.Color.Black;
            this.btnadd.IdleLineColor = System.Drawing.Color.Black;
            this.btnadd.Location = new System.Drawing.Point(164, 294);
            this.btnadd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(77, 34);
            this.btnadd.TabIndex = 30;
            this.btnadd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::bismillah_jadi.Properties.Resources.icons8_check_for_payment_96;
            this.pictureBox1.Location = new System.Drawing.Point(11, 59);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(18, 18);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::bismillah_jadi.Properties.Resources.icons8_java_bean_96;
            this.pictureBox2.Location = new System.Drawing.Point(11, 24);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(18, 18);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 24;
            this.pictureBox2.TabStop = false;
            // 
            // txtplusnama
            // 
            this.txtplusnama.BackColor = System.Drawing.Color.Cyan;
            this.txtplusnama.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtplusnama.Location = new System.Drawing.Point(169, 59);
            this.txtplusnama.MaxLength = 50;
            this.txtplusnama.Name = "txtplusnama";
            this.txtplusnama.Size = new System.Drawing.Size(155, 20);
            this.txtplusnama.TabIndex = 14;
            this.txtplusnama.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtname_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(151, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(12, 18);
            this.label1.TabIndex = 13;
            this.label1.Text = ":";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(151, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(12, 18);
            this.label2.TabIndex = 12;
            this.label2.Text = ":";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(35, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 18);
            this.label3.TabIndex = 1;
            this.label3.Text = "Nama Supplier";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(35, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 18);
            this.label4.TabIndex = 0;
            this.label4.Text = "ID Supplier";
            // 
            // perbaruisupplier
            // 
            this.perbaruisupplier.BackColor = System.Drawing.Color.Cyan;
            this.perbaruisupplier.Controls.Add(this.pictureBox8);
            this.perbaruisupplier.Controls.Add(this.pictureBox10);
            this.perbaruisupplier.Controls.Add(this.pictureBox9);
            this.perbaruisupplier.Controls.Add(this.pictureBox11);
            this.perbaruisupplier.Controls.Add(this.pictureBox12);
            this.perbaruisupplier.Controls.Add(this.label26);
            this.perbaruisupplier.Controls.Add(this.pictureBox7);
            this.perbaruisupplier.Controls.Add(this.txtharga);
            this.perbaruisupplier.Controls.Add(this.label13);
            this.perbaruisupplier.Controls.Add(this.label14);
            this.perbaruisupplier.Controls.Add(this.txtidbahan);
            this.perbaruisupplier.Controls.Add(this.label15);
            this.perbaruisupplier.Controls.Add(this.label16);
            this.perbaruisupplier.Controls.Add(this.txtemail);
            this.perbaruisupplier.Controls.Add(this.label17);
            this.perbaruisupplier.Controls.Add(this.label18);
            this.perbaruisupplier.Controls.Add(this.txtaddress);
            this.perbaruisupplier.Controls.Add(this.label19);
            this.perbaruisupplier.Controls.Add(this.label20);
            this.perbaruisupplier.Controls.Add(this.txteditid);
            this.perbaruisupplier.Controls.Add(this.bunifuCustomDataGrid1);
            this.perbaruisupplier.Controls.Add(this.btnhapus);
            this.perbaruisupplier.Controls.Add(this.btnupdate);
            this.perbaruisupplier.Controls.Add(this.txtname);
            this.perbaruisupplier.Controls.Add(this.label21);
            this.perbaruisupplier.Controls.Add(this.label22);
            this.perbaruisupplier.Controls.Add(this.label23);
            this.perbaruisupplier.Controls.Add(this.label24);
            this.perbaruisupplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.perbaruisupplier.Location = new System.Drawing.Point(0, 47);
            this.perbaruisupplier.Name = "perbaruisupplier";
            this.perbaruisupplier.Size = new System.Drawing.Size(586, 374);
            this.perbaruisupplier.TabIndex = 71;
            this.perbaruisupplier.Visible = false;
            this.perbaruisupplier.Paint += new System.Windows.Forms.PaintEventHandler(this.perbaruisupplier_Paint);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(169, 246);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(24, 13);
            this.label26.TabIndex = 52;
            this.label26.Text = "Rp.";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::bismillah_jadi.Properties.Resources.icons8_check_for_payment_96;
            this.pictureBox7.Location = new System.Drawing.Point(11, 243);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(18, 18);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 50;
            this.pictureBox7.TabStop = false;
            // 
            // txtharga
            // 
            this.txtharga.BackColor = System.Drawing.Color.Cyan;
            this.txtharga.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtharga.Location = new System.Drawing.Point(198, 243);
            this.txtharga.MaxLength = 10;
            this.txtharga.Name = "txtharga";
            this.txtharga.Size = new System.Drawing.Size(126, 20);
            this.txtharga.TabIndex = 49;
            this.txtharga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtplushargabahan_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(151, 243);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(12, 18);
            this.label13.TabIndex = 48;
            this.label13.Text = ":";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(35, 243);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 18);
            this.label14.TabIndex = 47;
            this.label14.Text = "Harga Bahan";
            // 
            // txtidbahan
            // 
            this.txtidbahan.BackColor = System.Drawing.Color.Cyan;
            this.txtidbahan.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtidbahan.Location = new System.Drawing.Point(169, 203);
            this.txtidbahan.MaxLength = 10;
            this.txtidbahan.Name = "txtidbahan";
            this.txtidbahan.Size = new System.Drawing.Size(155, 20);
            this.txtidbahan.TabIndex = 45;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(151, 203);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(12, 18);
            this.label15.TabIndex = 44;
            this.label15.Text = ":";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(35, 203);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 18);
            this.label16.TabIndex = 43;
            this.label16.Text = "ID Bahan";
            // 
            // txtemail
            // 
            this.txtemail.BackColor = System.Drawing.Color.Cyan;
            this.txtemail.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtemail.Location = new System.Drawing.Point(169, 166);
            this.txtemail.MaxLength = 50;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(155, 20);
            this.txtemail.TabIndex = 41;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(151, 166);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(12, 18);
            this.label17.TabIndex = 40;
            this.label17.Text = ":";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(35, 166);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(40, 18);
            this.label18.TabIndex = 39;
            this.label18.Text = "Email";
            // 
            // txtaddress
            // 
            this.txtaddress.BackColor = System.Drawing.Color.Cyan;
            this.txtaddress.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtaddress.Location = new System.Drawing.Point(169, 95);
            this.txtaddress.MaxLength = 100;
            this.txtaddress.Multiline = true;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(155, 53);
            this.txtaddress.TabIndex = 37;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(151, 95);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(12, 18);
            this.label19.TabIndex = 36;
            this.label19.Text = ":";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(35, 95);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 18);
            this.label20.TabIndex = 35;
            this.label20.Text = "Alamat";
            // 
            // txteditid
            // 
            this.txteditid.BackColor = System.Drawing.Color.Cyan;
            this.txteditid.DataSource = this.supplierBindingSource;
            this.txteditid.DisplayMember = "id_supplier";
            this.txteditid.FormattingEnabled = true;
            this.txteditid.Location = new System.Drawing.Point(169, 24);
            this.txteditid.MaxLength = 10;
            this.txteditid.Name = "txteditid";
            this.txteditid.Size = new System.Drawing.Size(154, 21);
            this.txteditid.TabIndex = 34;
            this.txteditid.ValueMember = "id_supplier";
            this.txteditid.SelectedIndexChanged += new System.EventHandler(this.txteditid_SelectedIndexChanged);
            // 
            // bunifuCustomDataGrid1
            // 
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuCustomDataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.bunifuCustomDataGrid1.AutoGenerateColumns = false;
            this.bunifuCustomDataGrid1.BackgroundColor = System.Drawing.Color.LightCyan;
            this.bunifuCustomDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuCustomDataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuCustomDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.bunifuCustomDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bunifuCustomDataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idsupplierDataGridViewTextBoxColumn1,
            this.namasupplierDataGridViewTextBoxColumn1,
            this.alamatDataGridViewTextBoxColumn1,
            this.emailDataGridViewTextBoxColumn1,
            this.idbahanDataGridViewTextBoxColumn1,
            this.hargabahanDataGridViewTextBoxColumn1});
            this.bunifuCustomDataGrid1.DataSource = this.supplierBindingSource;
            this.bunifuCustomDataGrid1.DoubleBuffered = true;
            this.bunifuCustomDataGrid1.EnableHeadersVisualStyles = false;
            this.bunifuCustomDataGrid1.GridColor = System.Drawing.Color.DarkSlateGray;
            this.bunifuCustomDataGrid1.HeaderBgColor = System.Drawing.Color.LightSeaGreen;
            this.bunifuCustomDataGrid1.HeaderForeColor = System.Drawing.Color.Black;
            this.bunifuCustomDataGrid1.Location = new System.Drawing.Point(341, 24);
            this.bunifuCustomDataGrid1.Name = "bunifuCustomDataGrid1";
            this.bunifuCustomDataGrid1.ReadOnly = true;
            this.bunifuCustomDataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.bunifuCustomDataGrid1.Size = new System.Drawing.Size(235, 266);
            this.bunifuCustomDataGrid1.TabIndex = 33;
            // 
            // idsupplierDataGridViewTextBoxColumn1
            // 
            this.idsupplierDataGridViewTextBoxColumn1.DataPropertyName = "id_supplier";
            this.idsupplierDataGridViewTextBoxColumn1.HeaderText = "ID Supplier";
            this.idsupplierDataGridViewTextBoxColumn1.Name = "idsupplierDataGridViewTextBoxColumn1";
            this.idsupplierDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // namasupplierDataGridViewTextBoxColumn1
            // 
            this.namasupplierDataGridViewTextBoxColumn1.DataPropertyName = "nama_supplier";
            this.namasupplierDataGridViewTextBoxColumn1.HeaderText = "Nama Supplier";
            this.namasupplierDataGridViewTextBoxColumn1.Name = "namasupplierDataGridViewTextBoxColumn1";
            this.namasupplierDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // alamatDataGridViewTextBoxColumn1
            // 
            this.alamatDataGridViewTextBoxColumn1.DataPropertyName = "alamat";
            this.alamatDataGridViewTextBoxColumn1.HeaderText = "Alamat";
            this.alamatDataGridViewTextBoxColumn1.Name = "alamatDataGridViewTextBoxColumn1";
            this.alamatDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // emailDataGridViewTextBoxColumn1
            // 
            this.emailDataGridViewTextBoxColumn1.DataPropertyName = "email";
            this.emailDataGridViewTextBoxColumn1.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn1.Name = "emailDataGridViewTextBoxColumn1";
            this.emailDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // idbahanDataGridViewTextBoxColumn1
            // 
            this.idbahanDataGridViewTextBoxColumn1.DataPropertyName = "id_bahan";
            this.idbahanDataGridViewTextBoxColumn1.HeaderText = "ID Bahan";
            this.idbahanDataGridViewTextBoxColumn1.Name = "idbahanDataGridViewTextBoxColumn1";
            this.idbahanDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // hargabahanDataGridViewTextBoxColumn1
            // 
            this.hargabahanDataGridViewTextBoxColumn1.DataPropertyName = "harga_bahan";
            this.hargabahanDataGridViewTextBoxColumn1.HeaderText = "Harga Bahan";
            this.hargabahanDataGridViewTextBoxColumn1.Name = "hargabahanDataGridViewTextBoxColumn1";
            this.hargabahanDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // btnhapus
            // 
            this.btnhapus.ActiveBorderThickness = 1;
            this.btnhapus.ActiveCornerRadius = 20;
            this.btnhapus.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnhapus.ActiveForecolor = System.Drawing.Color.White;
            this.btnhapus.ActiveLineColor = System.Drawing.Color.Black;
            this.btnhapus.BackColor = System.Drawing.Color.Cyan;
            this.btnhapus.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnhapus.BackgroundImage")));
            this.btnhapus.ButtonText = "Hapus";
            this.btnhapus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnhapus.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhapus.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnhapus.IdleBorderThickness = 1;
            this.btnhapus.IdleCornerRadius = 20;
            this.btnhapus.IdleFillColor = System.Drawing.Color.White;
            this.btnhapus.IdleForecolor = System.Drawing.Color.Black;
            this.btnhapus.IdleLineColor = System.Drawing.Color.Black;
            this.btnhapus.Location = new System.Drawing.Point(247, 294);
            this.btnhapus.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnhapus.Name = "btnhapus";
            this.btnhapus.Size = new System.Drawing.Size(77, 34);
            this.btnhapus.TabIndex = 31;
            this.btnhapus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnhapus.Click += new System.EventHandler(this.btnhapus_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.ActiveBorderThickness = 1;
            this.btnupdate.ActiveCornerRadius = 20;
            this.btnupdate.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnupdate.ActiveForecolor = System.Drawing.Color.White;
            this.btnupdate.ActiveLineColor = System.Drawing.Color.Black;
            this.btnupdate.BackColor = System.Drawing.Color.Cyan;
            this.btnupdate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnupdate.BackgroundImage")));
            this.btnupdate.ButtonText = "Perbarui";
            this.btnupdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnupdate.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnupdate.IdleBorderThickness = 1;
            this.btnupdate.IdleCornerRadius = 20;
            this.btnupdate.IdleFillColor = System.Drawing.Color.White;
            this.btnupdate.IdleForecolor = System.Drawing.Color.Black;
            this.btnupdate.IdleLineColor = System.Drawing.Color.Black;
            this.btnupdate.Location = new System.Drawing.Point(164, 294);
            this.btnupdate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(77, 34);
            this.btnupdate.TabIndex = 30;
            this.btnupdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // txtname
            // 
            this.txtname.BackColor = System.Drawing.Color.Cyan;
            this.txtname.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtname.Location = new System.Drawing.Point(169, 59);
            this.txtname.MaxLength = 50;
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(155, 20);
            this.txtname.TabIndex = 14;
            this.txtname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtname_KeyPress);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(151, 24);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(12, 18);
            this.label21.TabIndex = 13;
            this.label21.Text = ":";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(151, 59);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(12, 18);
            this.label22.TabIndex = 12;
            this.label22.Text = ":";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(35, 59);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(96, 18);
            this.label23.TabIndex = 1;
            this.label23.Text = "Nama Supplier";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(35, 24);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(79, 18);
            this.label24.TabIndex = 0;
            this.label24.Text = "ID Supplier";
            // 
            // supplierTableAdapter
            // 
            this.supplierTableAdapter.ClearBeforeFill = true;
            // 
            // bahan_BakuTableAdapter
            // 
            this.bahan_BakuTableAdapter.ClearBeforeFill = true;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox9.Image = global::bismillah_jadi.Properties.Resources.icons8_name_96;
            this.pictureBox9.Location = new System.Drawing.Point(11, 59);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(18, 18);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 56;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox11.Image = global::bismillah_jadi.Properties.Resources.icons8_home_address_96;
            this.pictureBox11.Location = new System.Drawing.Point(11, 95);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(18, 18);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 54;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox12.Image = global::bismillah_jadi.Properties.Resources.icons8_name_tag_woman_horizontal_96;
            this.pictureBox12.Location = new System.Drawing.Point(11, 24);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(18, 18);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 53;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox10.Image = global::bismillah_jadi.Properties.Resources.icons8_email_open_96;
            this.pictureBox10.Location = new System.Drawing.Point(11, 166);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(18, 18);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 82;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::bismillah_jadi.Properties.Resources.icons8_java_bean_96;
            this.pictureBox8.Location = new System.Drawing.Point(11, 203);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(18, 18);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 83;
            this.pictureBox8.TabStop = false;
            // 
            // CRUD_Supplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.Controls.Add(this.perbaruisupplier);
            this.Controls.Add(this.tambahsuplier);
            this.Controls.Add(this.panel1);
            this.Name = "CRUD_Supplier";
            this.Size = new System.Drawing.Size(586, 421);
            this.Load += new System.EventHandler(this.CRUD_Supplier_Load);
            this.panel1.ResumeLayout(false);
            this.tambahsuplier.ResumeLayout(false);
            this.tambahsuplier.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bahanBakuBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.koDingDataSet20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.update)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.koDingDataSet19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.perbaruisupplier.ResumeLayout(false);
            this.perbaruisupplier.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuFlatButton btnperbaruibahan;
        private Bunifu.Framework.UI.BunifuFlatButton btntambahbahan;
        private System.Windows.Forms.Panel tambahsuplier;
        private System.Windows.Forms.PictureBox pictureBox6;
        private Bunifu.Framework.BunifuCustomTextbox txtplushargabahan;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox5;
        private Bunifu.Framework.BunifuCustomTextbox txtid;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox4;
        private Bunifu.Framework.BunifuCustomTextbox txtpluxemail;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox3;
        private Bunifu.Framework.BunifuCustomTextbox txtplusalamat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private Bunifu.Framework.UI.BunifuCustomDataGrid update;
        private Bunifu.Framework.UI.BunifuThinButton2 btnclear;
        private Bunifu.Framework.UI.BunifuThinButton2 btnadd;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Bunifu.Framework.BunifuCustomTextbox txtplusnama;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel perbaruisupplier;
        private System.Windows.Forms.PictureBox pictureBox7;
        private Bunifu.Framework.BunifuCustomTextbox txtharga;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private Bunifu.Framework.BunifuCustomTextbox txtidbahan;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private Bunifu.Framework.BunifuCustomTextbox txtemail;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private Bunifu.Framework.BunifuCustomTextbox txtaddress;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox txteditid;
        private Bunifu.Framework.UI.BunifuCustomDataGrid bunifuCustomDataGrid1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnhapus;
        private Bunifu.Framework.UI.BunifuThinButton2 btnupdate;
        private Bunifu.Framework.BunifuCustomTextbox txtname;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.DataGridViewTextBoxColumn idsupplierDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn namasupplierDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn alamatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idbahanDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hargabahanDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource supplierBindingSource;
        private KoDingDataSet19 koDingDataSet19;
        private KoDingDataSet19TableAdapters.SupplierTableAdapter supplierTableAdapter;
        private System.Windows.Forms.BindingSource bahanBakuBindingSource;
        private KoDingDataSet20 koDingDataSet20;
        private KoDingDataSet20TableAdapters.Bahan_BakuTableAdapter bahan_BakuTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idsupplierDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn namasupplierDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn alamatDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idbahanDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn hargabahanDataGridViewTextBoxColumn1;
        private System.Windows.Forms.ComboBox txtplusidbahan;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox8;
    }
}
