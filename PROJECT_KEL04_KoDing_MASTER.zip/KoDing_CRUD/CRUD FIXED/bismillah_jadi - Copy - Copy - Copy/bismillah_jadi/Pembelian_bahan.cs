﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace bismillah_jadi
{
    public partial class Pembelian_bahan : UserControl
    {
        public Pembelian_bahan()
        {
            InitializeComponent();
        }

        private void Pembelian_bahan_Load(object sender, EventArgs e)
        {
            string query = "select no_pembelian from [dbo].[Transaksi Pembelian Bahan Baku] order by no_pembelian desc";
            bunifuCustomTextbox1.Text = autoNumber("TRSB-", query);

            this.detail_Pembelian_Bahan_BakuTableAdapter.Fill(this.koDingDataSet2.Detail_Pembelian_Bahan_Baku);
            this.supplierTableAdapter.Fill(this.koDingDataSet1.Supplier);
        }

        private string autoNumber(string firstText, string query)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            string result = "";
            int num = 0;
            try
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            SqlCommand dbcmd = connection.CreateCommand();
            string sql = "select id_bahan from [dbo].[Supplier] where nama_supplier='" + comboBox1.Text + "'";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();

            while (reader.Read())
            {
                
                comboBox2.Items.Add(reader.GetValue(0).ToString());
            }
        }



        private void bunifuCustomTextbox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsDigit(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            SqlCommand dbcmd = connection.CreateCommand();
            string sql = "select harga_bahan from [dbo].[Supplier] where id_bahan='" + comboBox2.Text + "'";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();
            bunifuCustomTextbox4.Text = reader.GetValue(0).ToString();
            
        }

        private void bunifuCustomTextbox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void bunifuCustomTextbox6_Enter(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();


            try
            {
                if (bunifuCustomTextbox1.Text == "" || bunifuCustomTextbox2.Text == "" || bunifuCustomTextbox4.Text == "" || bunifuCustomTextbox6.Text == "" || comboBox1.Text == "" || comboBox2.Text  == "" )
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    SqlCommand insert = new SqlCommand("sp_InsertDetailPembelian", connection);
                    insert.CommandType = CommandType.StoredProcedure;
                    insert.Parameters.AddWithValue("@id_supplier", comboBox1.ValueMember);
                    insert.Parameters.AddWithValue("@no_pembelian", bunifuCustomTextbox1.Text);
                    insert.Parameters.AddWithValue("@jumlah_bahan", bunifuCustomTextbox2.Text);
                    insert.Parameters.AddWithValue("@biaya_kirim", bunifuCustomTextbox6.Text);
                    insert.Parameters.AddWithValue("@id_bahan", comboBox2.Text);
                    insert.Parameters.AddWithValue("@harga", bunifuCustomTextbox4.Text);

                    int numRes = insert.ExecuteNonQuery();
                    if (numRes > 0)
                    {
                        clear();
                        Refreshdata();

                        string query = "select no_pembelian from [dbo].[Transaksi Pembelian Bahan Baku] order by no_pembelian desc";
                        bunifuCustomTextbox1.Text = autoNumber("TRSB-", query);
                    }
                    else
                        MessageBox.Show("Gagal Menyimpan! Coba Lagi!");
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void clear()
        {
            bunifuCustomTextbox1.Clear();
            comboBox1.Text = "";
            comboBox2.Text = "";
            bunifuCustomTextbox2.Text = "";
            bunifuCustomTextbox4.Text = "";
            bunifuCustomTextbox6.Text = "";
        }

        private void Refreshdata()
        {
            this.detail_Pembelian_Bahan_BakuTableAdapter.Fill(this.koDingDataSet2.Detail_Pembelian_Bahan_Baku);
        }
    }
}
