﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bismillah_jadi
{
    public partial class Kelola_Karyawan : Form
    {
        public Kelola_Karyawan()
        {
            InitializeComponent();
        }

        private void kelola_Akun1_Load(object sender, EventArgs e)
        {

        }

        private void Kelola_Karyawan_Load(object sender, EventArgs e)
        {
            label2.Text = Thread.CurrentPrincipal.Identity.Name;
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            jam_Lembur1.Visible = true;
        }
    }
}
