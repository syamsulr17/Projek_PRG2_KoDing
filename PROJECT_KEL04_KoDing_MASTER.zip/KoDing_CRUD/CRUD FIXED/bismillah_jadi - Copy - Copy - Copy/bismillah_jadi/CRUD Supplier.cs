﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace bismillah_jadi
{
    public partial class CRUD_Supplier : UserControl
    {
        public CRUD_Supplier()
        {
            InitializeComponent();
        }

        private void CRUD_Supplier_Load(object sender, EventArgs e)
        {
            string query = "select id_supplier from [dbo].[Supplier] order by id_supplier desc";
            txtid.Text = autoNumber("SPR-", query);

            this.supplierTableAdapter.Fill(this.koDingDataSet19.Supplier);
            this.bahan_BakuTableAdapter.Fill(this.koDingDataSet20.Bahan_Baku);
            txtplusidbahan.Text = "---Pilih ID Bahan---";
            txteditid.Text = "---Pilih ID Supplier---";
        }
        private void Refreshdata()
        {
            this.supplierTableAdapter.Fill(this.koDingDataSet19.Supplier);
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            try
            {
                if (txtid.Text == "" || txtplusalamat.Text == "" || txtplushargabahan.Text == "" || txtplusidbahan.Text == "" || txtplusnama.Text == "" || txtpluxemail.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (EmailIsValid(txtpluxemail.Text) == false)
                {
                    MessageBox.Show("Format Email Tidak Sesuai! Contoh : a@b.c", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                if (cek(txtplusidbahan.Text) == false)
                {
                    MessageBox.Show("Masukan ID Bahan Yang Valid!");
                    txtplusidbahan.Focus();
                }
                else
                {
                    SqlCommand insert = new SqlCommand("sp_InsertSupplier", connection);
                    insert.CommandType = CommandType.StoredProcedure;

                    insert.Parameters.AddWithValue("@id_supplier", txtid.Text);
                    insert.Parameters.AddWithValue("@nama_supplier", txtplusnama.Text);
                    insert.Parameters.AddWithValue("@alamat", txtplusalamat.Text);
                    insert.Parameters.AddWithValue("@email", txtpluxemail.Text);
                    insert.Parameters.AddWithValue("@id_bahan", txtplusidbahan.Text);
                    insert.Parameters.AddWithValue("@harga_bahan", txtplushargabahan.Text);
                        int numRes = insert.ExecuteNonQuery();
                        if (numRes > 0)
                        {
                            MessageBox.Show("Data Supplier Berhasil Disimpan!","Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            clear();
                            Refreshdata();

                            string query = "select id_supplier from [dbo].[Supplier] order by id_supplier desc";
                            txtid.Text = autoNumber("SPR-", query);
                        }
                        else
                            MessageBox.Show("Gagal Menyimpan! Coba Lagi!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private string autoNumber(string firstText, string query)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            string result = "";
            int num = 0;
            try
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;

        }

        public static bool EmailIsValid(string email)
        {
            string regexPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$";

            if (Regex.IsMatch(email, regexPattern))
            {
                if (Regex.Replace(email, regexPattern, string.Empty).Length == 0)
                {
                    return true;
                }
            }
            return false;
        }
        private Boolean cek(string id)
        {


            id = id.ToUpper();
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            SqlCommand dbcmd = connection.CreateCommand();
            string sql = "select id_bahan from [dbo].[Bahan Baku] where id_bahan='" + txtplusidbahan.Text + "'";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();

            while (reader.Read())
            {
                if ((reader.GetString(0).ToString().ToUpper() == id))
                {
                    return true;
                }
            }
            connection.Close();
            return false;
        }

        private void clear()
        {
            txtplushargabahan.Text = "";
            txtplusidbahan.Text = "";
            txtplusnama.Text = "";
            txtpluxemail.Text = "";
            txtplusalamat.Text = "";
            
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            try
            {
                if (txteditid.Text == "" || txtname.Text == "" || txtaddress.Text == "" || txtemail.Text == "" || txtidbahan.Text == "" || txtharga.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    SqlCommand insert = new SqlCommand("sp_UpdateSuplier", connection);
                    insert.CommandType = CommandType.StoredProcedure;

                    insert.Parameters.AddWithValue("@id_supplier", txteditid.Text);
                    insert.Parameters.AddWithValue("@nama_supplier", txtname.Text);
                    insert.Parameters.AddWithValue("@alamat", txtaddress.Text);
                    insert.Parameters.AddWithValue("@email", txtemail.Text);
                    insert.Parameters.AddWithValue("@harga_bahan", txtharga.Text);
                    insert.Parameters.AddWithValue("@id_bahan", txtidbahan.Text);
                    int numRes = insert.ExecuteNonQuery();
                    if (numRes > 0)
                    {

                        MessageBox.Show("Data Supplier Berhasil Diperbarui!", "Infomation!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        clear1();
                        Refreshdata();


                    } else
                    {
                        MessageBox.Show("Gagal Memperbarui! Coba Lagi!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
        private void clear1()
        {
            txtaddress.Text = "";
            txteditid.Text = "";
            txtemail.Text = "";
            txtharga.Text = "";
            txtidbahan.Text = "---Pilih ID Bahan---";
            txtname.Text = "";
        }

        private void btnhapus_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            try
            {
                if (txteditid.Text == "" || txtname.Text == "" || txtaddress.Text == "" || txtemail.Text == "" || txtidbahan.Text == "" || txtharga.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string message = "Hapus Data??";
                    string title = "Confirmation";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result = MessageBox.Show(message, title, buttons);
                    if (result == DialogResult.Yes)
                    {

                        SqlCommand delete = new SqlCommand("sp_DeleteSupplier", connection);
                        delete.CommandType = CommandType.StoredProcedure;

                        delete.Parameters.AddWithValue("@id_supplier", txteditid.Text);

                        int numRes = delete.ExecuteNonQuery();
                        if (numRes >= 0)
                        {
                            MessageBox.Show("Data Supplier Berhasil Dihapus!", "Infomation!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            clear1();
                            Refreshdata();
                        } else
                        {
                            MessageBox.Show("Gagal Menghapus! Coba Lagi!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                    }
                    else
                    {
                        clear1();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void btntambahbahan_Click(object sender, EventArgs e)
        {
            string query = "select id_supplier from [dbo].[Supplier] order by id_supplier desc";
            txtid.Text = autoNumber("SPR-", query);

            tambahsuplier.Visible = true;
            perbaruisupplier.Visible = false;
        }

        private void btnperbaruibahan_Click(object sender, EventArgs e)
        {
            perbaruisupplier.Visible = true;
            tambahsuplier.Visible = false;
        }

        private void txteditid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            SqlCommand dbcmd = connection.CreateCommand();
            string sql = "select * from [dbo].[Supplier] where id_supplier='" + txteditid.Text + "'";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();
            reader.Read();
            txtname.Text = reader.GetValue(1).ToString();
            txtaddress.Text = reader.GetValue(2).ToString();
            txtemail.Text = reader.GetValue(3).ToString();
            txtidbahan.Text = reader.GetValue(4).ToString();
            txtharga.Text = reader.GetValue(5).ToString();
        }

        private void txtplushargabahan_KeyPress(object sender, KeyPressEventArgs e)
        {

            if ((!char.IsDigit(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void perbaruisupplier_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsLetter(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
