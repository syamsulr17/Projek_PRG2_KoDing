﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Reflection;

namespace bismillah_jadi
{
    public partial class Jam_Lembur : UserControl
    {
        public Jam_Lembur()
        {
            InitializeComponent();
        }

        private void save_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();


            try
            {
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {


                    DataTable dtData = new DataTable();
                    SqlCommand insert = new SqlCommand("sp_InsertJamLembur", connection);
                    insert.CommandType = CommandType.StoredProcedure;
                    insert.Parameters.AddWithValue("@no_lembur", textBox1.Text);
                    insert.Parameters.AddWithValue("@jam_lembur", textBox2.Text);
                    insert.Parameters.AddWithValue("@tanggal_lembur", bunifuDatepicker1.Value);
                    insert.Parameters.AddWithValue("@id_pegawai", textBox3.Text);
                    int numRes = insert.ExecuteNonQuery();
                    if (numRes > 0)
                    {
                        MessageBox.Show("Data Lembur Berhasil Disimpan!");
                        clear();

                        string query = "select no_lembur from [dbo].[Jam Lembur] order by no_lembur desc";
                        textBox1.Text = autoNumber("LBR-", query);
                    }
                    else
                        MessageBox.Show("Gagal Menyimpan! Coba Lagi!");
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        public void clear()
        {
            textBox2.Text = "";
            textBox3.Text = "";
            bunifuDatepicker1.Value = DateTime.Now;
        }

        private string autoNumber(string firstText, string query)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            string result = "";
            int num = 0;
            try
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            
           
           if ((!char.IsDigit(e.KeyChar) && (!char.IsWhiteSpace(e.KeyChar))) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            try
            {
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    string tgl = DateTime.Today.Day.ToString();

                    SqlCommand insert = new SqlCommand("sp_UpdateJamLembur", connection);
                    insert.CommandType = CommandType.StoredProcedure;
                    insert.Parameters.AddWithValue("@no_lembur", textBox1.Text);
                    insert.Parameters.AddWithValue("@jam_lembur", textBox2.Text);
                    insert.Parameters.AddWithValue("@tanggal_lembur", bunifuDatepicker1.Value);
                    insert.Parameters.AddWithValue("@id_pegawai", textBox3.Text);
                    if (tgl == "28" || tgl == "29" || tgl == "30" || tgl == "31")
                    {
                        MessageBox.Show("Perubahan telah melewati batas waktu yang telah ditetapkan!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        int numRes = insert.ExecuteNonQuery();
                        if (numRes > 0)
                        {
                            MessageBox.Show("Data Lembur Berhasil Diperbarui!");
                            clear();

                            string query = "select no_lembur from [dbo].[Jam Lembur] order by no_lembur desc";
                            textBox1.Text = autoNumber("LBR-", query);
                        }
                        else
                            MessageBox.Show("Gagal Menyimpan! Coba Lagi!");
                    }

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();

            try
            {
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
                {
                    MessageBox.Show("Semua Data Harus Diisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string tgl = DateTime.Today.Day.ToString();
                    string message = "Hapus Data??";
                    string title = "Confirmation";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result = MessageBox.Show(message, title, buttons);
                    if (result == DialogResult.Yes)
                    {

                        SqlCommand delete = new SqlCommand("sp_DeleteJamLembur", connection);
                        delete.CommandType = CommandType.StoredProcedure;

                        delete.Parameters.AddWithValue("@no_lembur", textBox1.Text);

                        if (tgl == "28" || tgl == "29" || tgl == "30" || tgl == "31")
                        {
                            MessageBox.Show("Perubahan telah melewati batas waktu yang telah ditetapkan!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            int numRes = delete.ExecuteNonQuery();
                            if (numRes >= 0)
                            {
                                MessageBox.Show("Bahan Lembur Dihapus!", "Infomation!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                clear();
                                string query = "select no_lembur from [dbo].[Jam Lembur] order by no_lembur desc";
                                textBox1.Text = autoNumber("LBR-", query);
                            }
                            else
                            {
                                MessageBox.Show("Gagal Menghapus! Coba Lagi!");
                            }
                        }
                    }
                    else
                    {
                        clear();
                    }
                    
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void Jam_Lembur_Load(object sender, EventArgs e)
        {
            string query = "select no_lembur from [dbo].[Jam Lembur] order by no_lembur desc";
            textBox1.Text = autoNumber("LBR-", query);
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                if (cek(textBox1.Text) == false)
                {
                    textBox2.Text = "";
                    textBox3.Text = "";
                    bunifuDatepicker1.Value = DateTime.Now;
                   
                }
            }
        }

        private Boolean cek(string id)
        {


            id = id.ToUpper();
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            SqlCommand dbcmd = connection.CreateCommand();
            string sql = "select * from [dbo].[Jam Lembur] where no_lembur='" + textBox1.Text + "'";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();

            while (reader.Read())
            {
                if ((reader.GetString(0).ToString().ToUpper() == id))
                {
                    textBox2.Text = reader.GetValue(1).ToString();
                    textBox3.Text = reader.GetValue(3).ToString();
                    string ttl = reader.GetValue(2).ToString();
                    bunifuDatepicker1.Value = Convert.ToDateTime(ttl);
                   
                    return true;
                }
            }
            connection.Close();
            return false;
        }

        private Boolean cekid(string id)
        {
            id = id.ToUpper();
            string conn = "integrated security = true; data source =PUJIA\\SQLEXPRESS; initial catalog = KoDing";

            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            SqlCommand dbcmd = connection.CreateCommand();
            string sql = "select id_pegawai from Pegawai where id_pegawai='" + textBox3.Text + "'";
            dbcmd.CommandText = sql;
            SqlDataReader reader = dbcmd.ExecuteReader();

            while (reader.Read())
            {
                if ((reader.GetString(0).ToString().ToUpper() == id))
                {
                    return true;
                }
            }
            connection.Close();
            return false;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox3_Leave(object sender, EventArgs e)
        {
            if (textBox3.Text != "")
            {
                if (cekid(textBox3.Text) == false)
                {
                    MessageBox.Show("Nomor Karyawan Tidak Terdaftar!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBox3.Focus();
                }
               
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                textBox2.Clear();
                textBox3.Focus();

            }
        }
    }
}
